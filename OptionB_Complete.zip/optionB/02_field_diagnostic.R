# ===========================================================================
# OPTION B, TASK 3 - NEAR-OPTIMAL COEFFICIENT WIDTH ON THE REAL FIELD,
#                    AND ITS STABILITY TO TOLERANCE AND GRID DENSITY
#
# Strategy 6.2:  L_e(delta) = { lam in G : (G_e(lam) - G_min)/G_min <= delta }
#                W_e(delta) = max beta_B(lam) - min beta_B(lam) over L_e(delta)
# Strategy 6.2 also warns: "Record grid resolution and whether the linear
# boundary belongs to the candidate set; otherwise W_e is grid-dependent."
# That warning is the point of this script: we vary BOTH and measure.
#
# mgcv IS REQUIRED here - W must be computed on the same fits the field study
# used, not on a reconstructed basis.
# ===========================================================================
suppressMessages(library(mgcv))
d <- read.csv("proc.csv")
ES <- sort(unique(d$Easting))
DELTAS <- c(0.005, 0.01, 0.02, 0.05)
NGRID  <- c(41, 81, 121, 241, 481)
out <- NULL
for (ng in NGRID) {
  lg <- seq(-12, 25, length.out = ng)
  for (e in ES) {
    sl <- d[d$Easting == e, ]
    sl$Product <- factor(sl$Product, levels = c("E", "B"))
    n <- nrow(sl)
    g <- numeric(ng); b <- numeric(ng)
    for (j in 1:ng) {
      f <- gam(Yield ~ Product + s(Northing, bs = "bs", k = 10, m = c(3, 2)),
               data = sl, method = "GCV.Cp", sp = exp(lg[j]))
      ed <- sum(f$edf)
      g[j] <- n * sum(residuals(f)^2) / (n - ed)^2
      b[j] <- unname(coef(f)["ProductB"])
    }
    gm <- min(g)
    row <- data.frame(NGrid = ng, Easting = e, GCV_min = gm,
                      LogLam_min = lg[which.min(g)])
    for (dl in DELTAS) {
      keep <- which((g - gm) / gm <= dl)
      row[[paste0("W_", dl * 100)]]  <- max(b[keep]) - min(b[keep])
      row[[paste0("nL_", dl * 100)]] <- length(keep)
    }
    out <- rbind(out, row)
  }
  cat("grid", ng, "done\n"); flush.console()
}
write.csv(out, "OUT_field_W.csv", row.names = FALSE)
cat("\n== median W_e(delta) and count >= 0.25, by grid density ==\n")
cat(sprintf("%6s", "NGrid"))
for (dl in DELTAS) cat(sprintf("  med_W_%.1f%%  n>=.25_%.1f%%", dl*100, dl*100))
cat("\n")
for (ng in NGRID) {
  z <- out[out$NGrid == ng, ]
  cat(sprintf("%6d", ng))
  for (dl in DELTAS) {
    w <- z[[paste0("W_", dl * 100)]]
    cat(sprintf("  %10.4f  %12d", median(w), sum(w >= 0.25)))
  }
  cat("\n")
}
