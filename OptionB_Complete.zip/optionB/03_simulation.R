# ===========================================================================
# OPTION B, TASKS 4-5 - EXACT-mgcv KNOWN-TRUTH MONTE CARLO
#
# Strategy 7.2: retain the observed 24-vector of Northing and the actual 12/12
# Product assignment; generate Y = alpha + beta_true*p + f(N) + eps.
# Strategy 7.3: fit (1) automatic mgcv GCV, (2) lowest EVALUATED fixed-sp GCV,
# (3) REML, (4) exact linear-nullspace limit. Compute bias, RMSE, coverage.
#
# PRE-DECLARED BEFORE ANY OUTPUT WAS INSPECTED:
#   beta_true = 1.5            (strategy 8.3 prototype value)
#   sigma in {1, 3}            (low / high ambiguity; strategy leaves open)
#   AR(1) phi = 0.6            (strategy leaves open)
#   tau = 0.25 primary, 0.50 secondary   (strategy 7.5 requires tau up front;
#                                         0.25 is Paper 1's own convention)
#   B = 250 tuning + 250 evaluation per scenario, DISJOINT seeds (strategy 7.5
#   requires separate batches for tuning and evaluation)
#   grid = 121 points on log-lambda in [-12, 25]
#
# mgcv IS REQUIRED: the entire purpose of this task is the EXACT mgcv spline
# and selection procedure, which a reconstructed basis cannot stand in for.
# Functions are used in this driver; the derivative validation (script 01) is
# the function-free component.
# ===========================================================================
suppressMessages(library(mgcv))
ARGS <- commandArgs(trailingOnly = TRUE)
WHICH <- as.numeric(strsplit(ARGS[1], ",")[[1]])   # scenario ids for this stream

BETA_TRUE <- 1.5; ALPHA <- 10
PHI <- 0.6; TAUS <- c(0.25, 0.50)
NG <- 121; LG <- seq(-12, 25, length.out = NG)
DELTAS <- c(0.005, 0.01, 0.02, 0.05)
B_TUNE <- 250; B_EVAL <- 250

d <- read.csv("proc.csv"); s <- d[d$Easting == 216, ]; s <- s[order(s$Northing), ]
N <- as.numeric(s$Northing); P <- as.numeric(as.character(s$Product) == "B")
n <- length(N); u <- (N - min(N)) / (max(N) - min(N))

# Three nuisance profiles, exactly as strategy 7.2 specifies them
FS <- list(linear    = 3 * u,
           curved    = 5 * sin(2 * pi * u) + 2 * u^2,
           localized = 4 * exp(-((u - 0.5) / 0.13)^2))
SCEN <- expand.grid(f = names(FS), err = c("iid", "ar1"), sigma = c(1, 3),
                    stringsAsFactors = FALSE)
SCEN$id <- 1:nrow(SCEN)

# AR(1) Cholesky factor, built once (errors ordered by pass = ordered by Northing)
Rar <- PHI^abs(outer(1:n, 1:n, "-")); Lar <- t(chol(Rar))

J0 <- sum((P - mean(P))^2)                       # = 6 for the balanced design

allout <- NULL
for (sid in WHICH) {
  sc <- SCEN[SCEN$id == sid, ]
  fvec <- FS[[sc$f]]; sg <- sc$sigma
  for (batch in c("tune", "eval")) {
    Bn <- if (batch == "tune") B_TUNE else B_EVAL
    seed0 <- 10000 * sid + if (batch == "tune") 0 else 5000
    for (b in 1:Bn) {
      set.seed(seed0 + b)
      e <- if (sc$err == "iid") rnorm(n, 0, sg) else as.numeric(Lar %*% rnorm(n, 0, sg))
      yy <- ALPHA + BETA_TRUE * P + fvec + e
      dd <- data.frame(Yield = yy, Northing = N,
                       Product = factor(ifelse(P == 1, "B", "E"), levels = c("E", "B")))

      fa <- gam(Yield ~ Product + s(Northing, bs = "bs", k = 10, m = c(3, 2)),
                data = dd, method = "GCV.Cp")
      ea <- sum(fa$edf); ga <- n * sum(residuals(fa)^2) / (n - ea)^2
      ba <- unname(coef(fa)["ProductB"]); sa <- summary(fa)$se["ProductB"]

      fr <- gam(Yield ~ Product + s(Northing, bs = "bs", k = 10, m = c(3, 2)),
                data = dd, method = "REML")
      br <- unname(coef(fr)["ProductB"]); sr <- summary(fr)$se["ProductB"]

      lf <- lm(Yield ~ Product + I(Northing - mean(Northing)), data = dd)
      bl <- unname(coef(lf)[2]); sl <- summary(lf)$coefficients[2, 2]

      gg <- numeric(NG); bb <- numeric(NG); ee <- numeric(NG)
      for (j in 1:NG) {
        f <- gam(Yield ~ Product + s(Northing, bs = "bs", k = 10, m = c(3, 2)),
                 data = dd, method = "GCV.Cp", sp = exp(LG[j]))
        tt <- sum(f$edf); gg[j] <- n * sum(residuals(f)^2) / (n - tt)^2
        bb[j] <- unname(coef(f)["ProductB"]); ee[j] <- tt
      }
      jb <- which.min(gg); gm <- gg[jb]

      # near-optimal width at each declared tolerance
      Ws <- numeric(length(DELTAS)); nLs <- numeric(length(DELTAS))
      for (q in seq_along(DELTAS)) {
        kp <- which((gg - gm) / gm <= DELTAS[q])
        Ws[q] <- max(bb[kp]) - min(bb[kp]); nLs[q] <- length(kp)
      }
      # interior minima count on the evaluated grid
      nmin <- 0
      for (j in 2:(NG - 1)) if (gg[j - 1] > gg[j] && gg[j] < gg[j + 1]) nmin <- nmin + 1

      # overlap J and analytic derivative, in the ACTUAL mgcv basis at auto lambda
      Xf <- predict(fa, type = "lpmatrix")
      ip <- which(colnames(Xf) == "ProductB")
      Am <- Xf[, -ip, drop = FALSE]; pm <- Xf[, ip]
      Sm <- matrix(0, ncol(Am), ncol(Am))
      sidx <- fa$smooth[[1]]$first.para:fa$smooth[[1]]$last.para
      sidx2 <- sidx - (sidx > ip)
      Sm[sidx2, sidx2] <- fa$smooth[[1]]$S[[1]]
      lam <- fa$sp[1]
      Km <- crossprod(Am) + lam * Sm
      Ki <- tryCatch(solve(Km), error = function(z) NULL)
      Jv <- NA; dv <- NA
      if (!is.null(Ki)) {
        Mm <- diag(n) - Am %*% Ki %*% t(Am)
        Jv <- as.numeric(t(pm) %*% Mm %*% pm)
        bq <- as.numeric(t(pm) %*% Mm %*% yy) / Jv
        Md <- lam * Am %*% Ki %*% Sm %*% Ki %*% t(Am)
        dv <- as.numeric(t(pm) %*% Md %*% (yy - pm * bq)) / Jv
      }

      r <- data.frame(scenario = sid, f = sc$f, err = sc$err, sigma = sg,
        batch = batch, rep = b,
        beta_auto = ba, se_auto = sa, edf_auto = ea, gcv_auto = ga,
        loglam_auto = log(lam),
        beta_grid = bb[jb], gcv_grid = gm, edf_grid = ee[jb],
        beta_reml = br, se_reml = sr,
        beta_lin = bl, se_lin = sl,
        D_regret = ga - gm, dB_autogrid = ba - bb[jb],
        J_overlap = Jv, C_overlap = 1 - Jv / J0, deriv = dv, n_min = nmin)
      for (q in seq_along(DELTAS)) {
        r[[paste0("W_", DELTAS[q] * 100)]]  <- Ws[q]
        r[[paste0("nL_", DELTAS[q] * 100)]] <- nLs[q]
      }
      allout <- rbind(allout, r)
    }
    cat("scenario", sid, sc$f, sc$err, "sigma", sg, batch, "done\n"); flush.console()
  }
}
write.csv(allout, paste0("OUT_sim_", paste(WHICH, collapse = "_"), ".csv"), row.names = FALSE)
