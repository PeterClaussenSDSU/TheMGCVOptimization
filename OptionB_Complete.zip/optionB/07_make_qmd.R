ins <- function(f) paste(readLines(f), collapse="\n")
b <- function(lbl,title,body,lang="r") paste0("\n## ",title,"\n\n**",lbl,"**\n\n```{",lang,"}\n",body,"\n```\n")
o <- '---
title: "Option B: Coefficient-Aware Smoothing Diagnostic"
subtitle: "Complete executable record - every script, with provenance"
date: last-modified
format:
  pdf: {toc: true, toc-depth: 2, number-sections: true, geometry: margin=1in}
  html: {toc: true, embed-resources: true}
execute: {eval: false, echo: true, warning: false}
---

# What this is, and what was fixed in advance

This is the complete executable record of the Option B research test: the seven
tasks defined in the Paper 1 / Paper 2 publication strategy of 11 November 2026.
Chunks are `eval: false` so the document renders without repeating roughly
three quarters of a million model fits.

## Provenance labels

| Label | Meaning |
|---|---|
| `[VERBATIM]` | Exact contents of a file on disk, inserted programmatically, not retyped. |
| `[PRE-DECLARED]` | A choice fixed before any output was inspected. |
| `[REVIEWER ADDITION]` | Not in the strategy; added here and labelled as such. |

Every number in the accompanying report traces to a `OUT_*.csv` written by a
script printed below.

## Choices fixed before any simulation output was inspected

The strategy requires that the consequential-error threshold be set in advance,
and leaves several other quantities open. These were fixed first:

- `beta_true = 1.5`, `alpha = 10` (the strategy prototype value)
- `sigma` in {1, 3} - a low-ambiguity and a high-ambiguity regime
- AR(1) `phi = 0.6`
- `tau = 0.25` primary, `tau = 0.50` secondary (0.25 is Paper 1 own convention)
- 250 tuning + 250 evaluation replicates per scenario, disjoint seed streams
- 121-point log-lambda grid on [-12, 25] for the simulation

## Where this breaks the project standing code rules

Stated rather than buried.

1. **`library(mgcv)` is used** in scripts 02, 02b and 03. This is unavoidable:
   Task 4 is *defined* as reproducing the simulation under the exact `mgcv`
   specification, because the Version 1 pilot used a separately constructed
   penalized spline and therefore could not test the real selection procedure.
   A base R reconstruction cannot stand in for the thing being tested.
2. **The simulation driver defines functions.** Script 01, the derivative
   validation, is written in base R with no packages and no user-defined
   functions - it is the component where the rule could be kept, and it is kept.

## The seven tasks

| Task | What it required | Where |
|---|---|---|
| 1. Preserve Paper 1 | Freeze Stages 1A-4A | untouched; nothing here modifies them |
| 2. Validate the mathematics | Derivative vs finite differences | Section 2 |
| 3. Test diagnostic stability | Tolerance, grid density, boundary | Section 3 |
| 4. Exact-`mgcv` simulation | Known truth, controlled scenarios | Section 4 |
| 5. Compare estimators | Bias, RMSE, coverage | Section 5 |
| 6. Benchmark the diagnostic | Against simpler warning measures | Section 5 |
| 7. Novelty and scope | Does it beat the alternatives? | Section 6 |
'
o <- paste0(o, '
# Task 2: validating the coefficient sensitivity mathematics

## What is being tested

The strategy derives a penalized partial-regression identity and its
derivative. Writing `A` for the unpenalized intercept plus centred spline basis
(24x10), `S_A` for the integrated squared second-derivative penalty, `p` for the
Product B indicator and `rho = log(lambda)`:

$$\\widehat\\beta_B(\\lambda)=\\frac{p^\\top M_\\lambda y}{p^\\top M_\\lambda p},
\\qquad M_\\lambda=I-AK_\\lambda^{-1}A^\\top,\\qquad K_\\lambda=A^\\top A+\\lambda S_A$$

$$\\dot M_\\rho=\\lambda AK_\\lambda^{-1}S_AK_\\lambda^{-1}A^\\top,\\qquad
\\frac{d\\widehat\\beta_B}{d\\rho}=\\frac{p^\\top\\dot M_\\rho(y-p\\widehat\\beta_B)}{p^\\top M_\\lambda p}$$

A correct analytic derivative must match a centred finite difference of the same
`beta` function to order `h^2`. The strategy requires this check before the
derivative may be treated as an implemented diagnostic.

The script builds the basis from scratch by Cox-de Boor recursion, assembles the
penalty by three-point Simpson quadrature on each knot span (exact, because the
product of two cubic second derivatives is piecewise quadratic), and centres the
basis by QR so the intercept and smooth are identifiable.
')
o <- paste0(o, b("[VERBATIM] `01_derivative_validation.R` - base R, no packages, no functions",
  "Derivative validation", ins("01_derivative_validation.R")))
o <- paste0(o, '
# Task 3: stability of the near-optimal coefficient width

## Definition and the hazard in it

$$\\mathcal L_e(\\delta)=\\Big\\{\\lambda\\in\\mathcal G:\\frac{G_e(\\lambda)-G^{grid}_{e,\\min}}{G^{grid}_{e,\\min}}\\le\\delta\\Big\\},\\qquad
W_e(\\delta)=\\max_{\\mathcal L_e(\\delta)}\\widehat\\beta_{B,e}-\\min_{\\mathcal L_e(\\delta)}\\widehat\\beta_{B,e}$$

`G` is a **finite grid**, so `W` is a property of the grid as much as of the
model. The strategy anticipates exactly this and asks that grid resolution be
recorded. The script below measures the dependence rather than recording it:
five grid densities crossed with four tolerances, over all 199 Eastings.
')
o <- paste0(o, b("[VERBATIM] `02_field_diagnostic.R`","Grid-density and tolerance sweep", ins("02_field_diagnostic.R")))
o <- paste0(o, b("[VERBATIM] `02b_field_600.R`","Confirming the previously reported field figures", ins("02b_field_600.R")))
o <- paste0(o, '
# Task 4: the exact-`mgcv` known-truth simulation

## Why the Version 1 simulation did not settle this

The earlier 2,400-response pilot used a separately constructed penalized spline.
It is a valid feasibility experiment, but the object under test *is* the `mgcv`
selection procedure, so a different basis cannot stand in for it. Every fit
below uses the identical specification the field study used.

## Design

$$Y_i^{(b)}=\\alpha+\\beta_{true}p_i+f(N_i)+\\varepsilon_i^{(b)}$$

with the observed 24 Northing positions and the actual 12/12 Product assignment
retained from Easting 216, the three nuisance profiles the strategy specifies,
and two error structures. Four procedures are compared on every response:
automatic GCV, the lowest evaluated fixed-`sp` candidate, REML, and the exact
linear-nullspace limit computed in closed form by `lm`.
')
o <- paste0(o, b("[VERBATIM] `03_simulation.R`","Simulation driver", ins("03_simulation.R")))
o <- paste0(o, '
# Tasks 5-6: performance and the diagnostic benchmark

## The decision problem

Following the strategy, the operationally consequential event is
`A_b = 1{|beta_auto - beta_true| > tau}` with `tau` fixed in advance. Each
candidate score gets a threshold chosen on the **tuning** batch by maximising
Youden J, then evaluated on the disjoint **evaluation** batch. AUC is computed
on the evaluation batch only.

## A baseline the strategy does not list

**[REVIEWER ADDITION]** `SE(beta_auto)`, the standard error already printed by
`summary.gam`, is included as a competitor. It is the obvious one: free,
universally available, and it also grows when the coefficient is poorly
determined. If `W` merely tracks it, `W` tells a user nothing they did not
already have, and the Option B novelty gate fails on its own terms.
')
o <- paste0(o, b("[VERBATIM] `04_benchmark.R`","Estimator comparison and benchmark", ins("04_benchmark.R")))
o <- paste0(o, '
## Robustness of a negative result

A diagnostic can fail on average and still be useful where it matters. This
script repeats the comparison inside subsets chosen to favour `W`: replicates
with multiple detected grid minima, replicates where the automatic selection is
inferior, and replicates in the top quartile of `W` itself. It also computes a
partial rank correlation to test whether what signal `W` has is simply the
standard error in disguise.
')
o <- paste0(o, b("[VERBATIM] `04b_subset_check.R`","Subset robustness check", ins("04b_subset_check.R")))
o <- paste0(o, b("[VERBATIM] `05_figures.R`","Figures, base R graphics only", ins("05_figures.R")))
o <- paste0(o, '
# Building the report

The LaTeX report is generated from the saved CSVs, and its **verdict text is
written conditionally in code** from the measured AUC gap and likelihood-ratio
test. The conclusion therefore cannot be fitted to the result after the fact.
')
o <- paste0(o, b("[VERBATIM] `06_make_report.R`","Report generator, part 1", ins("06_make_report.R")))
o <- paste0(o, b("[VERBATIM] `06b_report_part2.R`","Report generator, part 2", ins("06b_report_part2.R")))
o <- paste0(o, '
# Run order

```bash
Rscript 01_derivative_validation.R
Rscript 02_field_diagnostic.R
Rscript 02b_field_600.R
Rscript 03_simulation.R 1,2,3,4,5,6     # two streams, run in parallel
Rscript 03_simulation.R 7,8,9,10,11,12
Rscript 04_benchmark.R
Rscript 05_figures.R
Rscript 06_make_report.R                # sources 06b
pdflatex OptionB_Report.tex
```

Inputs: `proc.csv` only (= `Example1SmoothHarvestPasses.csv`, renamed;
byte-identical, md5 `2e2a10f1053e115a87c7255ec6595c11`). Everything else is
produced by the scripts above. `mgcv` is required.
')
writeLines(o, "OptionB_Record.qmd")
cat("qmd written,", length(strsplit(o,"\n")[[1]]), "lines\n")
