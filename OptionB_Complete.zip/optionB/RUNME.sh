#!/bin/bash
# Full Option B pipeline in dependency order. See README.txt.
set -e
cd "$(dirname "$0")"
[ -f proc.csv ] || { echo "MISSING proc.csv - see README.txt"; exit 1; }
Rscript -e 'if(!requireNamespace("mgcv",quietly=TRUE)) stop("mgcv not installed")'
echo "[1/7] derivative validation";   Rscript 01_derivative_validation.R
echo "[2/7] field grid-density sweep"; Rscript 02_field_diagnostic.R
echo "[3/7] field 600-point check";    Rscript 02b_field_600.R
echo "[4/7] simulation (~1h, 2 streams)"
Rscript 03_simulation.R 1,2,3,4,5,6 > sim1.log 2>&1 &
Rscript 03_simulation.R 7,8,9,10,11,12 > sim2.log 2>&1 &
wait
echo "[5/7] benchmark";  Rscript 04_benchmark.R | tee benchmark.log
                         Rscript 04b_subset_check.R | tee subset.log
echo "[6/7] figures";    Rscript 05_figures.R
echo "[7/7] report";     Rscript 06_make_report.R
pdflatex -interaction=nonstopmode OptionB_Report.tex >/dev/null
pdflatex -interaction=nonstopmode OptionB_Report.tex >/dev/null
Rscript 07_make_qmd.R
echo "done: OptionB_Report.pdf"
