# ===========================================================================
# OPTION B, TASK 2 - VALIDATE THE COEFFICIENT SENSITIVITY MATHEMATICS
#
# Strategy section 5.2 requires: "Implement the derivative with the same
# explicit A, S_A used to fit the manual spline, then compare the derivative
# against centered finite differences for several rho values."
#
# RESTRICTIONS HONOURED: base R only, no library(), no user-defined functions.
# Everything below is explicit loops and matrix algebra.
#
# WHAT IS BEING TESTED
#   beta_B(lambda) = (p' M_lam y) / (p' M_lam p),  M_lam = I - A K_lam^-1 A'
#   K_lam = A'A + lam*S_A,  rho = log(lambda)
#   dM/drho    = lam * A K^-1 S_A K^-1 A'            <- Mdot
#   dbeta/drho = p' Mdot (y - p*beta) / (p' M_lam p)
# A correct analytic derivative must match a centred finite difference of the
# SAME beta function to O(h^2).
# ===========================================================================

d <- read.csv("proc.csv")
EAST <- 216                              # strategy section 6.4 worked example
s <- d[d$Easting == EAST, ]
s <- s[order(s$Northing), ]
y <- as.numeric(s$Yield)
x <- as.numeric(s$Northing)
p <- as.numeric(as.character(s$Product) == "B")
n <- length(y)

# --- STEP 1: knot vector -----------------------------------------------------
# k=10 cubic (degree 3) B-splines need k+degree+1 = 14 knots. Eight "real"
# knots span the data (two endpoints + six interior, equally spaced); three
# extended knots on each side carry the recursion past the boundary.
kdim <- 10; deg <- 3
real <- seq(min(x), max(x), length.out = 8)
h <- real[2] - real[1]
knots <- c(min(x) - 3:1 * h, real, max(x) + 1:3 * h)
stopifnot(length(knots) == kdim + deg + 1)

# --- STEP 2: Cox-de Boor recursion, written out as loops ---------------------
# Order 1 (degree 0) basis: indicator of each knot span, with the last span
# closed on the right so x = max(x) is not dropped.
B <- matrix(0, n, length(knots) - 1)
for (i in 1:n) for (j in 1:(length(knots) - 1)) {
  if (j < length(knots) - 1) {
    if (x[i] >= knots[j] && x[i] < knots[j + 1]) B[i, j] <- 1
  } else {
    if (x[i] >= knots[j] && x[i] <= knots[j + 1]) B[i, j] <- 1
  }
}
# Raise the degree three times. Each pass applies
#   B_{j,q}(x) = (x-t_j)/(t_{j+q}-t_j) B_{j,q-1} + (t_{j+q+1}-x)/(t_{j+q+1}-t_{j+1}) B_{j+1,q-1}
for (q in 1:deg) {
  Bn <- matrix(0, n, ncol(B) - 1)
  for (j in 1:ncol(Bn)) {
    den1 <- knots[j + q] - knots[j]
    den2 <- knots[j + q + 1] - knots[j + 1]
    for (i in 1:n) {
      t1 <- 0; t2 <- 0
      if (den1 > 0) t1 <- (x[i] - knots[j]) / den1 * B[i, j]
      if (den2 > 0) t2 <- (knots[j + q + 1] - x[i]) / den2 * B[i, j + 1]
      Bn[i, j] <- t1 + t2
    }
  }
  B <- Bn
}
stopifnot(ncol(B) == kdim)
cat(sprintf("B-spline basis %d x %d; max |rowSums - 1| = %.3e  (partition of unity)\n",
            nrow(B), ncol(B), max(abs(rowSums(B) - 1))))

# --- STEP 3: integrated squared second derivative penalty --------------------
# S_jk = integral B_j''(u) B_k''(u) du. The product of two cubic second
# derivatives is piecewise quadratic, so 3-point Simpson is EXACT on each span.
# Second derivatives come from the standard B-spline derivative recursion,
# applied twice, evaluated at the three Simpson abscissae of every knot span.
Ss <- matrix(0, kdim, kdim)
for (sp in 4:(length(knots) - 4)) {
  a <- knots[sp]; b <- knots[sp + 1]
  if (b <= a) next
  us <- c(a, (a + b) / 2, b); wt <- (b - a) / 6 * c(1, 4, 1)
  for (m in 1:3) {
    u <- us[m]
    # degree-1 basis at u (order 2), then differentiate up to cubic twice
    Bl <- numeric(length(knots) - 1)
    for (j in 1:(length(knots) - 1))
      if (u >= knots[j] && u < knots[j + 1]) Bl[j] <- 1
    if (u == knots[length(knots) - 1]) Bl[length(knots) - 1] <- 1
    for (q in 1:1) {
      nb <- numeric(length(Bl) - 1)
      for (j in 1:length(nb)) {
        d1 <- knots[j + q] - knots[j]; d2 <- knots[j + q + 1] - knots[j + 1]
        v1 <- 0; v2 <- 0
        if (d1 > 0) v1 <- (u - knots[j]) / d1 * Bl[j]
        if (d2 > 0) v2 <- (knots[j + q + 1] - u) / d2 * Bl[j + 1]
        nb[j] <- v1 + v2
      }
      Bl <- nb
    }
    # Bl now holds degree-1 B-splines. Second derivative of the degree-3
    # basis is a double difference of these, with the standard scaling.
    d2b <- numeric(kdim)
    for (j in 1:kdim) {
      c1 <- 0; c2 <- 0; c3 <- 0
      e1 <- knots[j + 3] - knots[j + 1]; e2 <- knots[j + 4] - knots[j + 2]
      g1 <- knots[j + 2] - knots[j + 1]; g2 <- knots[j + 3] - knots[j + 2]
      g3 <- knots[j + 4] - knots[j + 3]
      if (e1 > 0 && g1 > 0) c1 <-  6 / e1 / g1
      if (e1 > 0 && g2 > 0) c2 <- -6 / e1 / g2
      if (e2 > 0 && g2 > 0) c2 <- c2 - 6 / e2 / g2
      if (e2 > 0 && g3 > 0) c3 <-  6 / e2 / g3
      v <- 0
      if (j     <= length(Bl)) v <- v + c1 * Bl[j]
      if (j + 1 <= length(Bl)) v <- v + c2 * Bl[j + 1]
      if (j + 2 <= length(Bl)) v <- v + c3 * Bl[j + 2]
      d2b[j] <- v
    }
    for (a1 in 1:kdim) for (a2 in 1:kdim)
      Ss[a1, a2] <- Ss[a1, a2] + wt[m] * d2b[a1] * d2b[a2]
  }
}
Ss <- (Ss + t(Ss)) / 2
ev <- eigen(Ss, symmetric = TRUE, only.values = TRUE)$values
cat(sprintf("penalty rank = %d of %d (null space = constant + linear, so 8 expected)\n",
            sum(ev > max(ev) * 1e-10), kdim))

# --- STEP 4: A and S_A -------------------------------------------------------
# A holds the UNPENALIZED intercept plus the nuisance spline (strategy 5.1).
# The spline is centred so that intercept and smooth are identifiable.
qrz <- qr(crossprod(B, rep(1, n)))
Z <- qr.Q(qrz, complete = TRUE)[, 2:kdim]
Bc <- B %*% Z; Sc <- t(Z) %*% Ss %*% Z
A  <- cbind(1, Bc)
SA <- matrix(0, ncol(A), ncol(A)); SA[2:ncol(A), 2:ncol(A)] <- Sc
cat(sprintf("A is %d x %d, rank %d;  p'p centred J0 = %.4f\n",
            nrow(A), ncol(A), qr(cbind(A, p))$rank, sum((p - mean(p))^2)))

# --- STEP 5: analytic derivative vs centred finite difference ----------------
# For each rho: build K, M, beta, Mdot, analytic dbeta/drho; then recompute
# beta at rho +/- h directly and form the centred difference.
cat("\n   rho        beta_B      analytic d/drho    centred FD        abs diff      rel diff\n")
res <- NULL
for (rho in c(-6, -4, -2, 0, 2, 4, 6, 8, 10)) {
  lam <- exp(rho)
  K  <- crossprod(A) + lam * SA
  Ki <- solve(K)
  M  <- diag(n) - A %*% Ki %*% t(A)
  J  <- as.numeric(t(p) %*% M %*% p)
  bq <- as.numeric(t(p) %*% M %*% y) / J
  Md <- lam * A %*% Ki %*% SA %*% Ki %*% t(A)          # dM/drho
  an <- as.numeric(t(p) %*% Md %*% (y - p * bq)) / J   # strategy 5.2 boxed
  hh <- 1e-4; bb <- numeric(2)
  for (q in 1:2) {
    lq <- exp(rho + c(hh, -hh)[q])
    Kq <- crossprod(A) + lq * SA
    Mq <- diag(n) - A %*% solve(Kq) %*% t(A)
    bb[q] <- as.numeric(t(p) %*% Mq %*% y) / as.numeric(t(p) %*% Mq %*% p)
  }
  fd <- (bb[1] - bb[2]) / (2 * hh)
  cat(sprintf("%7.1f  %12.7f  %16.9f  %16.9f  %12.3e  %12.3e\n",
              rho, bq, an, fd, abs(an - fd), abs(an - fd)/max(abs(fd), 1e-12)))
  res <- rbind(res, data.frame(rho = rho, beta_B = bq, analytic = an,
               finite_diff = fd, abs_diff = abs(an - fd),
               rel_diff = abs(an - fd)/max(abs(fd), 1e-12),
               J_rho = J, overlap_C = 1 - J/sum((p - mean(p))^2)))
}
write.csv(res, "OUT_derivative_validation.csv", row.names = FALSE)
cat(sprintf("\nMAX relative discrepancy across all rho: %.3e\n", max(res$rel_diff)))
cat(sprintf("Overlap C(rho) ranges %.4f to %.4f; J ranges %.4f to %.4f (J0=6)\n",
            min(res$overlap_C), max(res$overlap_C), min(res$J_rho), max(res$J_rho)))
