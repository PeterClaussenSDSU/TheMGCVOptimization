# Part 2 of the report generator: simulation, benchmark, verdict.
# Sourced after part 1; relies on the objects part 1 created.
ad("\\section{Task 4--5: known-truth simulation and estimator performance}",
"\\paragraph{Design.} Retaining the observed 24 Northing positions and the actual 12/12 Product",
"assignment at Easting 216, responses were generated as",
"\\begin{equation}Y_i^{(b)}=\\alpha+\\beta_{\\mathrm{true}}p_i+f(N_i)+\\varepsilon_i^{(b)},",
"\\qquad \\beta_{\\mathrm{true}}=1.5,\\end{equation}",
"with $u$ the Northing rescaled to $[0,1]$ and the three nuisance profiles the strategy specifies:",
"$f_1(u)=3u$, $f_2(u)=5\\sin(2\\pi u)+2u^2$, $f_3(u)=4\\exp[-((u-0.5)/0.13)^2]$. Errors are either",
"independent $N(0,\\sigma^2)$ or AR(1) with $\\mathrm{Cov}(\\varepsilon_i,\\varepsilon_j)=",
"\\sigma^2\\phi^{|i-j|}$, $\\phi=0.6$, ordered by pass. Every response was fitted with the identical",
"specification \\texttt{Yield \\textasciitilde{} Product + s(Northing, bs=\"bs\", k=10, m=c(3,2))}.",
"\\paragraph{Why this matters.} The Version 1 simulation used a separately constructed penalized",
"spline. It could not test the actual selection procedure. This one does.")
ad("\\begin{table}[h]\\centering\\footnotesize",
"\\caption{Bias, RMSE and empirical coverage of nominal 95\\% intervals against the known",
"$\\beta_{\\mathrm{true}}=1.5$. Coverage is undefined for the best-evaluated-grid candidate, which has",
"no accompanying interval.}",
"\\begin{tabular}{llr rrr rr rrr rrr}\\toprule",
"& & & \\multicolumn{3}{c}{automatic GCV} & \\multicolumn{2}{c}{best grid} &",
"\\multicolumn{3}{c}{REML} & \\multicolumn{3}{c}{linear limit}\\\\",
"\\cmidrule(lr){4-6}\\cmidrule(lr){7-8}\\cmidrule(lr){9-11}\\cmidrule(lr){12-14}",
"$f$ & err & $\\sigma$ & bias & rmse & cov & bias & rmse & bias & rmse & cov & bias & rmse & cov\\\\\\midrule")
for (i in order(pf$sigma, pf$err, pf$f)) ad(sprintf(
 "%s & %s & %g & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f & %.3f\\\\",
 pf$f[i], pf$err[i], pf$sigma[i], pf$bias_auto[i], pf$rmse_auto[i], pf$cover_auto[i],
 pf$bias_grid[i], pf$rmse_grid[i], pf$bias_reml[i], pf$rmse_reml[i], pf$cover_reml[i],
 pf$bias_lin[i], pf$rmse_lin[i], pf$cover_lin[i]))
ad("\\bottomrule\\end{tabular}\\end{table}")

bestcount <- c(auto=sum(pf$rmse_auto<=pmin(pf$rmse_grid,pf$rmse_reml,pf$rmse_lin)+1e-12),
               grid=sum(pf$rmse_grid<=pmin(pf$rmse_auto,pf$rmse_reml,pf$rmse_lin)+1e-12),
               reml=sum(pf$rmse_reml<=pmin(pf$rmse_auto,pf$rmse_grid,pf$rmse_lin)+1e-12),
               lin =sum(pf$rmse_lin <=pmin(pf$rmse_auto,pf$rmse_grid,pf$rmse_reml)+1e-12))
ad(sprintf(paste0("\\paragraph{The central Option B question, answered.} Across the %d scenarios the ",
"lowest RMSE belongs to the automatic GCV fit in %d, to the best evaluated grid candidate in %d, to ",
"REML in %d and to the exact linear limit in %d. Mean RMSE: automatic %.4f, best grid %.4f, REML %.4f, ",
"linear %.4f. \\key{Choosing the lower GCV score does not reliably produce a better estimate of the ",
"treatment effect.} Median absolute RMSE difference between the automatic fit and the best evaluated ",
"grid candidate is %.5f, which is negligible beside the differences among nuisance scenarios."),
 nrow(pf), bestcount["auto"], bestcount["grid"], bestcount["reml"], bestcount["lin"],
 mean(pf$rmse_auto), mean(pf$rmse_grid), mean(pf$rmse_reml), mean(pf$rmse_lin),
 median(abs(pf$rmse_auto-pf$rmse_grid))))
ad(sprintf(paste0("\\paragraph{Coverage.} Nominal 95\\%% intervals attain mean empirical coverage ",
"%.3f (automatic) and %.3f (REML) under independent errors, and %.3f / %.3f under AR(1). ",
"The strategy warned that a model-based interval ignoring selection and correlation is not guaranteed ",
"to hold its nominal level; %s"),
 mean(pf$cover_auto[pf$err=="iid"]), mean(pf$cover_reml[pf$err=="iid"]),
 mean(pf$cover_auto[pf$err=="ar1"]), mean(pf$cover_reml[pf$err=="ar1"]),
 if (mean(pf$cover_auto[pf$err=="ar1"]) < 0.90)
   "under AR(1) errors it does not, and the shortfall is substantial." else
   "the observed shortfall is modest here."))
ad("\\begin{figure}[h]\\centering\\includegraphics[width=\\textwidth]{fig3_rmse_bias.pdf}",
"\\caption{RMSE and bias by scenario and method. Labels are nuisance/error/$\\sigma$.}\\end{figure}")
ad("\\begin{figure}[h]\\centering\\includegraphics[width=0.92\\textwidth]{fig4_coverage.pdf}",
"\\caption{Empirical coverage of nominal 95\\% intervals; the dashed line is 0.95.}\\end{figure}")

# ---------------- Task 6 ----------------
ad("\\section{Task 6: benchmarking the diagnostic}",
"\\paragraph{The decision problem.} Following the strategy, define the operationally consequential",
"event $A_b=\\mathbf 1\\{|\\widehat\\beta_{\\mathrm{auto}}-\\beta_{\\mathrm{true}}|>\\tau\\}$ with",
"$\\tau$ fixed in advance. Each candidate score is given a threshold chosen on the \\emph{tuning}",
"batch by maximising Youden's $J$, and is then evaluated on the disjoint \\emph{evaluation} batch.",
"\\paragraph{A baseline the strategy does not list.} We add $\\mathrm{SE}(\\widehat\\beta_{\\mathrm{auto}})$,",
"the standard error already printed by \\texttt{summary.gam}. It is the natural competitor: it is free,",
"it is universally available, and it too grows when the coefficient is poorly determined. If $W$ merely",
"tracks it, $W$ tells a user nothing new. This addition is ours, not the strategy's.")
for (tt in list(list(0.25,b25),list(0.50,b50))) {
  tau <- tt[[1]]; bb <- tt[[2]]; if (is.null(bb)) next
  A <- as.numeric(ev$err_auto > tau)
  ad(sprintf("\\subsection*{$\\tau=%.2f$ \\quad (event rate %.4f on the evaluation batch, %d of %d)}",
     tau, mean(A), sum(A), length(A)))
  ad("\\begin{table}[h]\\centering\\small\\begin{tabular}{lrrrr}\\toprule",
  "predictor & AUC (eval) & sensitivity & specificity & Youden $J$\\\\\\midrule")
  TEXLAB <- c(
    "W(0.5%)"="$W(0.5\\%)$", "W(1%)"="$W(1\\%)$", "W(2%)"="$W(2\\%)$", "W(5%)"="$W(5\\%)$",
    "|dbeta/drho|"="$|d\\widehat\\beta_B/d\\rho|$", "overlap C"="overlap $C$",
    "GCV regret D"="GCV regret $D$",
    "|b_auto-b_grid|"="$|\\widehat\\beta_{\\mathrm{auto}}-\\widehat\\beta_{\\mathrm{grid}}|$",
    "edf"="EDF", "EDF"="EDF",
    "SE(b_auto)  [reviewer baseline]"="$\\mathrm{SE}(\\widehat\\beta_{\\mathrm{auto}})$ \\ \\emph{[reviewer baseline]}")
  for (i in order(-bb$auc_eval)) {
    lb <- TEXLAB[[bb$predictor[i]]]
    if (is.null(lb)) lb <- gsub("_","\\\\_",gsub("%","\\\\%",bb$predictor[i]))
    ad(sprintf("%s & %.4f & %.4f & %.4f & %.4f\\\\", lb,
      bb$auc_eval[i], bb$sens_eval[i], bb$spec_eval[i], bb$youden_eval[i])) }
  ad("\\bottomrule\\end{tabular}\\end{table}")
}
ad("\\begin{figure}[h]\\centering\\includegraphics[width=\\textwidth]{fig5_roc.pdf}",
"\\caption{ROC curves on the evaluation batch at both pre-declared thresholds.}\\end{figure}")
ad("\\begin{figure}[h]\\centering\\includegraphics[width=\\textwidth]{fig6_W_vs_error.pdf}",
"\\caption{$W$ and the standard error against the actual estimation error.}\\end{figure}")

ad(sprintf(paste0("\\paragraph{Does $W$ add anything beyond the standard error?} On the evaluation ",
"batch at $\\tau=0.25$, the AUC of $W(1\\%%)$ is %.4f and that of ",
"$\\mathrm{SE}(\\widehat\\beta_{\\mathrm{auto}})$ is %.4f, a difference of %+.4f. GCV regret achieves ",
"%.4f. Adding $W(1\\%%)$ to a logistic model already containing $\\log\\mathrm{SE}$ gives a ",
"likelihood-ratio $p$-value of $%.3g$. The Spearman correlation between $W(1\\%%)$ and ",
"$\\mathrm{SE}$ is %.3f; between $W(1\\%%)$ and the realised $|$error$|$ it is %.3f, against %.3f for ",
"$\\mathrm{SE}$ itself."),
 auc_W, auc_SE, gain, auc_D, lrp,
 cor(ee$W_1, ee$se_auto, method="spearman"),
 cor(ee$W_1, ee$err_auto, method="spearman"),
 cor(ee$se_auto, ee$err_auto, method="spearman")))

ad("\\paragraph{Looking where the diagnostic should work best.} A diagnostic can fail on average and",
"still be useful where it matters. We therefore repeated the comparison inside the subsets in which",
"smoothing ambiguity is actually present. It does not help.")
ad("\\begin{table}[h]\\centering\\small",
"\\caption{AUC on the evaluation batch within subsets chosen to favour the diagnostic.}",
"\\begin{tabular}{lrrrr}\\toprule",
"subset & $n$ & event rate & AUC $W(1\\%)$ & AUC SE\\\\\\midrule")
for (i in which(SUB$tau==0.25)) ad(sprintf("%s & %d & %.3f & %.4f & %.4f\\\\",
  SUB$subset[i], SUB$n[i], SUB$rate[i], SUB$auc_W[i], SUB$auc_SE[i]))
ad("\\bottomrule\\end{tabular}\\end{table}")
ad(sprintf(paste0("The standard error wins in every subset, including replicates with multiple detected ",
"grid minima, replicates where the automatic selection is inferior, and replicates in the top quartile ",
"of $W$ itself. A partial rank correlation makes the reason plain: the Spearman correlation between ",
"$W(1\\%%)$ and the realised error is %.4f, but after removing $\\mathrm{SE}$ it falls to %.4f. ",
"\\key{What little signal $W$ carries is mostly the standard error in disguise.}"),
 cor(ev$W_1, ev$err_auto, method="spearman"),
 cor(resid(lm(rank(ev$W_1)~rank(ev$se_auto))), resid(lm(rank(ev$err_auto)~rank(ev$se_auto))))))

# ---------------- Task 7: verdict ----------------
ad("\\section{Task 7: novelty gate and recommendation}")
ad("\\paragraph{The rule, as the strategy states it.} \\emph{Proceed with Option B if a reproducible",
"coefficient-aware diagnostic exhibits useful, nontrivial performance beyond simpler measures, remains",
"numerically stable, and survives comparison with relevant existing methods. Return to Option A if the",
"diagnostic adds no meaningful information, cannot be calibrated, or substantially duplicates",
"established methodology.}")
ad("\\begin{table}[h]\\centering\\small\\caption{The gate, criterion by criterion.}",
"\\begin{tabular}{p{5.4cm}p{3.1cm}p{6.2cm}}\\toprule",
"Criterion & Result & Evidence\\\\\\midrule")
ad(sprintf("Mathematics correct & \\textbf{pass} & analytic derivative matches centred finite differences to $%.0e$\\\\", max(dv$abs_diff)))
ad(sprintf("Numerically stable & \\textbf{%s} & median $W(1\\%%)$ moves %.4f$\\to$%.4f across grid densities and has not converged\\\\",
  if (median(fw$W_1[fw$NGrid==481])/max(median(fw$W_1[fw$NGrid==241]),1e-9) < 1.05) "marginal" else "\\key{fail}",
  median(fw$W_1[fw$NGrid==41]), median(fw$W_1[fw$NGrid==481])))
ad(sprintf("Beats simpler measures & \\textbf{%s} & AUC %.4f for $W(1\\%%)$ against %.4f for the standard error (%+.4f)\\\\",
  if (gain > 0.02) "pass" else "\\key{fail}", auc_W, auc_SE, gain))
ad(sprintf("Adds information beyond SE & \\textbf{%s} & likelihood-ratio $p=%.3g$\\\\",
  if (lrp < 0.05) "pass" else "\\key{fail}", lrp))
ad("\\bottomrule\\end{tabular}\\end{table}")
ad(sprintf("\\paragraph{Verdict.} On the pre-declared primary criterion the gate \\key{%s}. The strategy's own decision rule therefore directs us to %s.", VERDICT, REC))

ad("\\section{Limitations}",
"\\begin{itemize}\\itemsep1pt",
"\\item One field geometry and one treatment arrangement. The 24-pass design is held fixed throughout,",
"so nothing here speaks to other designs.",
sprintf("\\item Monte Carlo error. With %d evaluation replicates per scenario, a rate near $0.10$ carries a standard error of about %.3f.", 250, sqrt(0.1*0.9/250)),
"\\item $\\sigma$ and $\\phi$ were fixed by us, not by the strategy, and the AR(1) structure is a",
"simulation assumption, not a verified description of the field.",
"\\item The diagnostic was evaluated against a single decision problem. A different $\\tau$, or a",
"different loss, could rank the predictors differently; both declared thresholds are reported.",
"\\item $W$ is defined on a finite grid. Section 3 shows this is not a technicality.",
"\\item Nothing here establishes the first-stage preprocessing provenance, which remains open and",
"belongs to the separate reviewer study.",
"\\end{itemize}")
ad("\\section*{Reproduction}",
"\\begin{verbatim}",
"Rscript 01_derivative_validation.R   # Task 2, base R, no packages, no functions",
"Rscript 02_field_diagnostic.R        # Task 3, grid-density sweep",
"Rscript 02b_field_600.R              # Task 3, confirm reported field figures",
"Rscript 03_simulation.R 1,2,3,4,5,6  # Tasks 4-5, stream 1",
"Rscript 03_simulation.R 7,8,9,10,11,12",
"Rscript 04_benchmark.R               # Tasks 5-6",
"Rscript 05_figures.R                 # figures",
"Rscript 06_make_report.R             # this document",
"\\end{verbatim}",
"\\end{document}")
writeLines(tex, "OptionB_Report.tex")
cat("OptionB_Report.tex written,", length(tex), "lines\n")
cat("VERDICT:", VERDICT, " AUC_W =", round(auc_W,4), " AUC_SE =", round(auc_SE,4), "\n")
