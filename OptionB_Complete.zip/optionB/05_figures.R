# ===========================================================================
# OPTION B - FIGURES. Base R graphics only; no plotting packages.
# Every figure is drawn from a saved OUT_*.csv, so each one is traceable to
# the script that produced its numbers.
# ===========================================================================
BETA_TRUE <- 1.5
pal <- c("#1f4e79", "#c0504d", "#4f81bd", "#9bbb59")

# --- F1: derivative validation ----------------------------------------------
dv <- read.csv("OUT_derivative_validation.csv")
pdf("fig1_derivative.pdf", width = 9, height = 4)
par(mfrow = c(1, 2), mar = c(4.2, 4.4, 2.4, 1))
plot(dv$rho, dv$analytic, type = "b", pch = 16, col = pal[1], lwd = 2,
     xlab = expression(rho == log~lambda), ylab = expression(d*hat(beta)[B]/d*rho),
     main = "Analytic derivative vs finite difference")
points(dv$rho, dv$finite_diff, pch = 1, cex = 1.8, col = pal[2], lwd = 2)
abline(h = 0, lty = 3, col = "grey50")
legend("bottomright", c("analytic", "centred FD"), pch = c(16, 1),
       col = pal[1:2], bty = "n", lwd = 2, lty = c(1, NA))
plot(dv$rho, pmax(dv$abs_diff, 1e-14), log = "y", type = "b", pch = 16,
     col = pal[1], lwd = 2, xlab = expression(rho), ylab = "|analytic - FD|",
     main = "Absolute discrepancy (log scale)")
abline(h = 1e-8, lty = 2, col = pal[2])
dev.off()

# --- F2: field W, and its stability -----------------------------------------
if (file.exists("OUT_field_W.csv")) {
  fw <- read.csv("OUT_field_W.csv")
  ngs <- sort(unique(fw$NGrid)); ref <- fw[fw$NGrid == max(ngs), ]
  pdf("fig2_field_W.pdf", width = 9, height = 6)
  par(mfrow = c(2, 1), mar = c(4.2, 4.6, 2.4, 1))
  plot(ref$Easting, ref$W_1, type = "h", col = pal[1], lwd = 2,
       xlab = "Easting", ylab = expression(W[e](1*"%")),
       main = sprintf("Near-optimal coefficient width across the field (grid = %d)", max(ngs)))
  abline(h = 0.25, lty = 2, col = pal[2])
  legend("topleft", sprintf("W >= 0.25 at %d of %d Eastings", sum(ref$W_1 >= 0.25), nrow(ref)),
         bty = "n", text.col = pal[2])
  mm <- sapply(ngs, function(g) sapply(c("W_0.5","W_1","W_2","W_5"),
         function(cc) median(fw[fw$NGrid == g, cc])))
  matplot(ngs, t(mm), type = "b", pch = 16, lwd = 2, col = pal, lty = 1, log = "x",
          xlab = "grid points on log-lambda", ylab = "median W",
          main = "Stability of the diagnostic to grid density")
  legend("topleft", c("0.5%","1%","2%","5%"), col = pal, lwd = 2, pch = 16, bty = "n")
  dev.off()
}

# --- F3/F4/F5: simulation ----------------------------------------------------
fs <- list.files(".", pattern = "^OUT_sim_.*\\.csv$")
if (length(fs)) {
  z <- do.call(rbind, lapply(fs, read.csv))
  z$err_auto <- abs(z$beta_auto - BETA_TRUE)
  pf <- read.csv("OUT_performance.csv")
  pf <- pf[order(pf$sigma, pf$err, pf$f), ]
  lbl <- paste0(substr(pf$f,1,4), "/", pf$err, "/s", pf$sigma)

  pdf("fig3_rmse_bias.pdf", width = 10, height = 6)
  par(mfrow = c(2, 1), mar = c(6.5, 4.6, 2.4, 1))
  m <- rbind(pf$rmse_auto, pf$rmse_grid, pf$rmse_reml, pf$rmse_lin)
  barplot(m, beside = TRUE, col = pal, names.arg = lbl, las = 2, cex.names = 0.7,
          ylab = expression(RMSE(hat(beta)[B])), main = "RMSE against the known truth")
  legend("topleft", c("automatic GCV","best evaluated grid","REML","exact linear limit"),
         fill = pal, bty = "n", cex = 0.85)
  m <- rbind(pf$bias_auto, pf$bias_grid, pf$bias_reml, pf$bias_lin)
  barplot(m, beside = TRUE, col = pal, names.arg = lbl, las = 2, cex.names = 0.7,
          ylab = expression(Bias(hat(beta)[B])), main = "Bias against the known truth")
  abline(h = 0, lwd = 1)
  dev.off()

  pdf("fig4_coverage.pdf", width = 9, height = 4.6)
  par(mar = c(6.5, 4.6, 2.4, 1))
  m <- rbind(pf$cover_auto, pf$cover_reml, pf$cover_lin)
  barplot(m, beside = TRUE, col = pal[c(1,3,4)], names.arg = lbl, las = 2,
          cex.names = 0.7, ylim = c(0, 1), ylab = "empirical coverage",
          main = "Coverage of nominal 95% intervals")
  abline(h = 0.95, lty = 2, lwd = 2, col = pal[2])
  legend("bottomleft", c("automatic GCV","REML","exact linear limit"),
         fill = pal[c(1,3,4)], bty = "n", cex = 0.85)
  dev.off()

  # ROC on the evaluation batch, W(1%) vs SE vs GCV regret
  ev <- z[z$batch == "eval", ]
  pdf("fig5_roc.pdf", width = 9, height = 4.6)
  par(mfrow = c(1, 2), mar = c(4.4, 4.4, 2.6, 1))
  for (tau in c(0.25, 0.50)) {
    A <- as.numeric(ev$err_auto > tau)
    plot(0:1, 0:1, type = "n", xlab = "1 - specificity", ylab = "sensitivity",
         main = sprintf("ROC, tau = %.2f  (event rate %.3f)", tau, mean(A)))
    abline(0, 1, lty = 3, col = "grey50")
    vv <- list(ev$W_1, ev$se_auto, ev$D_regret, abs(ev$dB_autogrid))
    nm <- c("W(1%)", "SE(beta_auto)", "GCV regret", "|b_auto-b_grid|")
    for (q in 1:4) {
      x <- vv[[q]]; o <- order(-x); a <- A[o]
      tpr <- cumsum(a) / max(sum(a), 1); fpr <- cumsum(1 - a) / max(sum(1 - a), 1)
      lines(c(0, fpr), c(0, tpr), col = pal[q], lwd = 2)
    }
    legend("bottomright", nm, col = pal, lwd = 2, bty = "n", cex = 0.8)
  }
  dev.off()

  pdf("fig6_W_vs_error.pdf", width = 9, height = 4.6)
  par(mfrow = c(1, 2), mar = c(4.4, 4.4, 2.6, 1))
  plot(ev$W_1, ev$err_auto, pch = 16, cex = 0.35, col = "#1f4e7955",
       xlab = expression(W[b](1*"%")), ylab = expression(group("|",hat(beta)[auto]-beta[true],"|")),
       main = sprintf("W vs actual error (Spearman %.3f)",
                      cor(ev$W_1, ev$err_auto, method = "spearman")))
  plot(ev$se_auto, ev$err_auto, pch = 16, cex = 0.35, col = "#c0504d55",
       xlab = expression(SE(hat(beta)[auto])), ylab = "",
       main = sprintf("SE vs actual error (Spearman %.3f)",
                      cor(ev$se_auto, ev$err_auto, method = "spearman")))
  dev.off()
}
cat("figures written\n")
