# Confirm the previously reported field figures (median W(1%) ~ 0.158, 70/199
# with W >= 0.25) on the SAME 600-point grid used by Stage 3C.
suppressMessages(library(mgcv))
d <- read.csv("proc.csv"); ES <- sort(unique(d$Easting))
NG <- 600; lg <- seq(-12, 25, length.out = NG); DL <- c(0.005,0.01,0.02,0.05)
out <- NULL
for (e in ES) {
  sl <- d[d$Easting==e,]; sl$Product <- factor(sl$Product, levels=c("E","B")); n <- nrow(sl)
  g <- numeric(NG); b <- numeric(NG)
  for (j in 1:NG) {
    f <- gam(Yield~Product+s(Northing,bs="bs",k=10,m=c(3,2)), data=sl,
             method="GCV.Cp", sp=exp(lg[j]))
    ed <- sum(f$edf); g[j] <- n*sum(residuals(f)^2)/(n-ed)^2
    b[j] <- unname(coef(f)["ProductB"])
  }
  gm <- min(g); r <- data.frame(Easting=e, GCV_min=gm)
  for (dl in DL) { kp <- which((g-gm)/gm <= dl)
    r[[paste0("W_",dl*100)]] <- max(b[kp])-min(b[kp]); r[[paste0("nL_",dl*100)]] <- length(kp) }
  out <- rbind(out, r)
}
write.csv(out, "OUT_field_W600.csv", row.names=FALSE)
for (dl in DL) cat(sprintf("delta=%.1f%%  median W = %.4f   n(W>=0.25) = %d\n",
  dl*100, median(out[[paste0("W_",dl*100)]]), sum(out[[paste0("W_",dl*100)]]>=0.25)))
