# ===========================================================================
# OPTION B, TASKS 5-6 - ESTIMATOR COMPARISON AND DIAGNOSTIC BENCHMARK
#
# Strategy 7.5: A_b = 1{|beta_auto - beta_true| > tau}. Test whether W_b(delta)
# or an overlap/derivative score predicts A_b BETTER than D_b or
# |beta_auto - beta_grid|. Evaluate sensitivity, specificity and a predeclared
# loss, using SEPARATE batches for tuning and evaluation.
#
# ADDITION BY THE REVIEWER, NOT IN THE STRATEGY, AND LABELLED AS SUCH:
#   the standard error SE(beta_auto) is included as a baseline predictor.
#   It is the obvious competitor - it is already printed by summary.gam, costs
#   nothing, and also grows when the coefficient is poorly determined. If W
#   merely tracks SE then W carries no information a user does not already
#   have, and Option B's novelty gate fails on its own terms.
# ===========================================================================
BETA_TRUE <- 1.5; TAUS <- c(0.25, 0.50)
fs <- list.files(".", pattern = "^OUT_sim_.*\\.csv$")
z <- do.call(rbind, lapply(fs, read.csv))
cat("replicates loaded:", nrow(z), " scenarios:", length(unique(z$scenario)), "\n\n")

z$err_auto <- abs(z$beta_auto - BETA_TRUE)
z$absdB    <- abs(z$dB_autogrid)
z$absderiv <- abs(z$deriv)

# ---------- TASK 5: bias, RMSE, coverage ------------------------------------
cat("== TASK 5: estimator performance vs known beta_true = 1.5 ==\n")
cat(sprintf("%-10s %-4s %5s | %-26s | %-26s | %-26s | %-26s\n", "nuisance","err","sig",
  "AUTOMATIC GCV","BEST EVALUATED GRID","REML","EXACT LINEAR LIMIT"))
cat(sprintf("%-10s %-4s %5s | %8s%8s%10s | %8s%8s%10s | %8s%8s%10s | %8s%8s%10s\n",
  "","","", "bias","rmse","cover","bias","rmse","cover","bias","rmse","cover","bias","rmse","cover"))
perf <- NULL
for (sid in sort(unique(z$scenario))) {
  w <- z[z$scenario == sid, ]
  rw <- c(); vals <- list()
  for (m in c("auto","grid","reml","lin")) {
    bm <- w[[paste0("beta_", m)]]
    bi <- mean(bm - BETA_TRUE); rm_ <- sqrt(mean((bm - BETA_TRUE)^2))
    sem <- if (m == "grid") NA else w[[paste0("se_", m)]]
    cv <- if (m == "grid") NA else
      mean(abs(bm - BETA_TRUE) <= 1.959964 * sem)
    rw <- c(rw, bi, rm_, cv); vals[[m]] <- c(bi, rm_, cv)
  }
  cat(sprintf("%-10s %-4s %5g | %8.3f%8.3f%10s | %8.3f%8.3f%10s | %8.3f%8.3f%10s | %8.3f%8.3f%10s\n",
    w$f[1], w$err[1], w$sigma[1],
    vals$auto[1], vals$auto[2], sprintf("%.3f", vals$auto[3]),
    vals$grid[1], vals$grid[2], "   --   ",
    vals$reml[1], vals$reml[2], sprintf("%.3f", vals$reml[3]),
    vals$lin[1],  vals$lin[2],  sprintf("%.3f", vals$lin[3])))
  perf <- rbind(perf, data.frame(scenario=sid, f=w$f[1], err=w$err[1], sigma=w$sigma[1],
    bias_auto=vals$auto[1], rmse_auto=vals$auto[2], cover_auto=vals$auto[3],
    bias_grid=vals$grid[1], rmse_grid=vals$grid[2],
    bias_reml=vals$reml[1], rmse_reml=vals$reml[2], cover_reml=vals$reml[3],
    bias_lin=vals$lin[1],  rmse_lin=vals$lin[2],  cover_lin=vals$lin[3],
    pct_D_gt_1e4 = mean(w$D_regret > 1e-4)))
}
write.csv(perf, "OUT_performance.csv", row.names = FALSE)
cat(sprintf("\nfraction of replicates with D_b > 1e-4 (inferior automatic): %.4f overall\n",
            mean(z$D_regret > 1e-4)))

# ---------- TASK 6: diagnostic benchmark ------------------------------------
PRED <- c("W_0.5","W_1","W_2","W_5","absderiv","C_overlap",
          "D_regret","absdB","edf_auto","se_auto")
LAB <- c("W(0.5%)","W(1%)","W(2%)","W(5%)","|dbeta/drho|","overlap C",
         "GCV regret D","|b_auto-b_grid|","EDF","SE(b_auto)  [reviewer baseline]")
tu <- z[z$batch == "tune", ]; ev <- z[z$batch == "eval", ]

for (tau in TAUS) {
  cat(sprintf("\n== TASK 6: predicting A_b = 1{|beta_auto - 1.5| > %.2f} ==\n", tau))
  cat(sprintf("   event rate: tuning %.4f (%d/%d), evaluation %.4f (%d/%d)\n",
    mean(tu$err_auto > tau), sum(tu$err_auto > tau), nrow(tu),
    mean(ev$err_auto > tau), sum(ev$err_auto > tau), nrow(ev)))
  At <- as.numeric(tu$err_auto > tau); Ae <- as.numeric(ev$err_auto > tau)
  if (sum(Ae) < 5 || sum(1 - Ae) < 5) { cat("   too few events; skipped\n"); next }
  cat(sprintf("\n%-34s %9s %9s %9s %9s %9s\n", "predictor",
              "AUC_eval", "cut(tune)", "sens", "spec", "Youden"))
  tab <- NULL
  for (q in seq_along(PRED)) {
    xt <- tu[[PRED[q]]]; xe <- ev[[PRED[q]]]
    ok <- is.finite(xt) & is.finite(At); xt <- xt[ok]; Atq <- At[ok]
    oke <- is.finite(xe) & is.finite(Ae); xe2 <- xe[oke]; Aeq <- Ae[oke]
    # AUC via Mann-Whitney on the EVALUATION batch
    r <- rank(xe2); n1 <- sum(Aeq == 1); n0 <- sum(Aeq == 0)
    auc <- (sum(r[Aeq == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
    # threshold chosen on the TUNING batch by max Youden J
    cand <- sort(unique(quantile(xt, probs = seq(0.01, 0.99, by = 0.01), na.rm = TRUE)))
    bestJ <- -1; bestc <- NA
    for (cc in cand) {
      se_ <- mean(xt[Atq == 1] >= cc); sp_ <- mean(xt[Atq == 0] < cc)
      if (se_ + sp_ - 1 > bestJ) { bestJ <- se_ + sp_ - 1; bestc <- cc }
    }
    se_e <- mean(xe2[Aeq == 1] >= bestc); sp_e <- mean(xe2[Aeq == 0] < bestc)
    cat(sprintf("%-34s %9.4f %9.4f %9.4f %9.4f %9.4f\n",
                LAB[q], auc, bestc, se_e, sp_e, se_e + sp_e - 1))
    tab <- rbind(tab, data.frame(tau=tau, predictor=LAB[q], auc_eval=auc,
      cut_tune=bestc, sens_eval=se_e, spec_eval=sp_e, youden_eval=se_e+sp_e-1))
  }
  write.csv(tab, sprintf("OUT_benchmark_tau%03d.csv", round(tau*100)), row.names=FALSE)

  # ---- decisive test: does W add anything beyond the standard error? -------
  cat(sprintf("\n   -- does W(1%%) add information beyond SE(beta_auto)? (evaluation batch) --\n"))
  ee <- ev[is.finite(ev$se_auto) & is.finite(ev$W_1), ]
  Aee <- as.numeric(ee$err_auto > tau)
  m0 <- glm(Aee ~ log(ee$se_auto), family = binomial)
  m1 <- glm(Aee ~ log(ee$se_auto) + ee$W_1, family = binomial)
  lr <- 2 * (logLik(m1) - logLik(m0))
  pv <- pchisq(as.numeric(lr), df = 1, lower.tail = FALSE)
  pr0 <- predict(m0); pr1 <- predict(m1)
  a0 <- (sum(rank(pr0)[Aee==1]) - sum(Aee)*(sum(Aee)+1)/2)/(sum(Aee)*sum(1-Aee))
  a1 <- (sum(rank(pr1)[Aee==1]) - sum(Aee)*(sum(Aee)+1)/2)/(sum(Aee)*sum(1-Aee))
  cat(sprintf("     AUC  SE only = %.4f ;  SE + W(1%%) = %.4f ;  gain = %+.4f\n", a0, a1, a1-a0))
  cat(sprintf("     likelihood-ratio test for adding W(1%%):  chi2 = %.3f, df = 1, p = %.4g\n",
              as.numeric(lr), pv))
  cat(sprintf("     Spearman cor(W(1%%), SE(beta_auto)) = %.4f\n",
              cor(ee$W_1, ee$se_auto, method = "spearman")))
  cat(sprintf("     Spearman cor(W(1%%), |error|)       = %.4f\n",
              cor(ee$W_1, ee$err_auto, method = "spearman")))
  cat(sprintf("     Spearman cor(SE,     |error|)       = %.4f\n",
              cor(ee$se_auto, ee$err_auto, method = "spearman")))
}
