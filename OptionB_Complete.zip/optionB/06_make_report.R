# ===========================================================================
# OPTION B - BUILD THE LaTeX REPORT FROM THE SAVED CSV OUTPUTS.
# The verdict text is generated CONDITIONALLY from the numbers, so the
# conclusion cannot be fitted to the result after the fact.
# ===========================================================================
BETA_TRUE <- 1.5
dv <- read.csv("OUT_derivative_validation.csv")
fw <- read.csv("OUT_field_W.csv")
f6 <- if (file.exists("OUT_field_W600.csv")) read.csv("OUT_field_W600.csv") else NULL
z  <- do.call(rbind, lapply(list.files(".", pattern="^OUT_sim_.*\\.csv$"), read.csv))
z$err_auto <- abs(z$beta_auto - BETA_TRUE); z$absdB <- abs(z$dB_autogrid)
z$absderiv <- abs(z$deriv)
pf <- read.csv("OUT_performance.csv")
b25 <- read.csv("OUT_benchmark_tau025.csv")
b50 <- if (file.exists("OUT_benchmark_tau050.csv")) read.csv("OUT_benchmark_tau050.csv") else NULL
ev <- z[z$batch=="eval",]

# ---- the decisive comparison, recomputed here for the verdict --------------
auc_W  <- b25$auc_eval[b25$predictor=="W(1%)"]
auc_SE <- b25$auc_eval[grepl("SE", b25$predictor)]
auc_D  <- b25$auc_eval[b25$predictor=="GCV regret D"]
ee <- ev[is.finite(ev$se_auto) & is.finite(ev$W_1),]
A <- as.numeric(ee$err_auto > 0.25)
m0 <- glm(A ~ log(ee$se_auto), family=binomial)
m1 <- glm(A ~ log(ee$se_auto) + ee$W_1, family=binomial)
lrp <- pchisq(2*as.numeric(logLik(m1)-logLik(m0)), 1, lower.tail=FALSE)
gain <- auc_W - auc_SE
PASS <- (gain > 0.02) && (lrp < 0.05)
VERDICT <- if (PASS) "PASSES" else "FAILS"
REC <- if (PASS)
 "proceed with Option B: the diagnostic carries information beyond the standard error" else
 "return to Option A and retain $W$ as a descriptive supplement only, exactly as the strategy's own decision rule prescribes"

esc <- function(s) gsub("%", "\\\\%", s, fixed=FALSE)
tex <- c()
ad <- function(...) tex <<- c(tex, ...)

ad("\\documentclass[11pt]{article}",
"\\usepackage[margin=1in]{geometry}\\usepackage{amsmath,amssymb,booktabs,longtable}",
"\\usepackage{graphicx}\\usepackage[table]{xcolor}\\usepackage{fancyhdr}\\usepackage{hyperref}",
"\\hypersetup{colorlinks=true,linkcolor=blue!50!black,urlcolor=blue!50!black}",
"\\pagestyle{fancy}\\fancyhf{}\\lhead{Option B research test}\\rhead{Results report}\\cfoot{\\thepage}",
"\\newcommand{\\key}[1]{\\textcolor{red!60!black}{\\textbf{#1}}}",
"\\title{\\textbf{Option B: A Coefficient-Aware Smoothing Diagnostic}\\\\",
"\\large Exact-\\texttt{mgcv} Known-Truth Evaluation, Benchmark, and Novelty Gate}",
"\\author{Reviewer computational report}\\date{November 2026}",
"\\begin{document}\\maketitle",
"\\begin{abstract}")
ad(sprintf(paste0("This report completes the seven Option B tasks. The analytic coefficient derivative ",
"is verified against centred finite differences to a maximum absolute discrepancy of $%.1e$. ",
"The near-optimal coefficient width $W_e(\\delta)$ is computed on the full field and is found to be ",
"\\key{strongly grid-dependent}: at $\\delta=1\\%%$ its median rises from %.4f on a 41-point grid to ",
"%.4f on a 481-point grid, with the count of Eastings at $W\\ge 0.25$ rising from %d to %d. ",
"A known-truth Monte Carlo using the exact \\texttt{mgcv} specification over %d scenarios and %s ",
"replicates compares automatic GCV, the best evaluated fixed-parameter candidate, REML and the exact ",
"linear limit on bias, RMSE and interval coverage. The diagnostic is then benchmarked against simpler ",
"alternatives on disjoint tuning and evaluation batches. On the pre-declared primary criterion the ",
"Option B novelty gate \\key{%s}."),
 max(dv$abs_diff),
 median(fw$W_1[fw$NGrid==41]), median(fw$W_1[fw$NGrid==481]),
 sum(fw$W_1[fw$NGrid==41]>=0.25), sum(fw$W_1[fw$NGrid==481]>=0.25),
 length(unique(z$scenario)), format(nrow(z), big.mark=","), VERDICT))
ad("\\end{abstract}")

ad("\\section{Scope, and what was fixed in advance}",
"This report executes the seven tasks of the Option B research test. It does not alter any Stage 1A--4A",
"result, and it does not use the separate reviewer preprocessing study, which the publication strategy",
"requires to remain independent.",
"\\paragraph{Pre-declared choices.} The strategy leaves several quantities open and requires that the",
"consequential-error threshold be fixed before the simulation is analysed. The following were fixed",
"before any simulation output was inspected:",
"\\begin{itemize}\\itemsep1pt",
"\\item $\\beta_{\\mathrm{true}}=1.5$, $\\alpha=10$ (the strategy's own prototype value).",
"\\item Error scale $\\sigma\\in\\{1,3\\}$, giving a low-ambiguity and a high-ambiguity regime.",
"\\item AR(1) dependence parameter $\\phi=0.6$.",
"\\item Consequential-error threshold $\\tau=0.25$ (primary) and $\\tau=0.50$ (secondary). The value",
"      $0.25$ is Paper 1's own coefficient-difference convention.",
"\\item $250$ tuning and $250$ evaluation replicates per scenario, on disjoint seed streams.",
"\\item A $121$-point $\\log\\lambda$ grid on $[-12,25]$ for the simulation.",
"\\end{itemize}",
"\\paragraph{Departures from the project's standing code rules.} Two are unavoidable and are stated",
"rather than hidden. First, \\texttt{mgcv} is \\emph{required}: Task 4 is defined as reproducing the",
"simulation under the exact \\texttt{mgcv} specification, which a reconstructed basis cannot stand in",
"for. Second, the simulation driver defines functions. The derivative validation in",
"\\texttt{01\\_derivative\\_validation.R} is written in base R with no packages and no user-defined",
"functions, and is the component where the rule could be honoured.")

# ---------------- Task 2 ----------------
ad("\\section{Task 2: the coefficient sensitivity mathematics is correct}",
"\\paragraph{What is being checked.} The strategy derives the penalized partial-regression identity",
"\\begin{equation}\\widehat\\beta_B(\\lambda)=\\frac{p^\\top M_\\lambda y}{p^\\top M_\\lambda p},\\qquad",
"M_\\lambda=I-AK_\\lambda^{-1}A^\\top,\\qquad K_\\lambda=A^\\top A+\\lambda S_A,\\end{equation}",
"and, with $\\rho=\\log\\lambda$ and $\\dot M_\\rho=\\lambda AK_\\lambda^{-1}S_AK_\\lambda^{-1}A^\\top$,",
"\\begin{equation}\\frac{d\\widehat\\beta_B}{d\\rho}",
"=\\frac{p^\\top\\dot M_\\rho\\,(y-p\\,\\widehat\\beta_B)}{p^\\top M_\\lambda p}.\\end{equation}",
"Here $A$ ($24\\times10$) holds the unpenalized intercept and the centred cubic B-spline basis, $S_A$",
"($10\\times10$) is the integrated squared second-derivative penalty with a zero block for the",
"intercept, and $p$ ($24\\times1$) is the Product B indicator. The strategy requires this be validated",
"against centred finite differences before the derivative is used as a diagnostic.",
"\\paragraph{Result.} It validates.")
ad("\\begin{table}[h]\\centering\\small",
"\\caption{Analytic derivative against centred finite differences at Easting 216, manual basis.}",
"\\begin{tabular}{rrrrr}\\toprule",
"$\\rho$ & $\\widehat\\beta_B$ & analytic $d\\widehat\\beta/d\\rho$ & centred FD & abs.\\ difference\\\\\\midrule")
for (i in 1:nrow(dv)) ad(sprintf("%.0f & %.6f & %.9f & %.9f & %.2e\\\\", dv$rho[i], dv$beta_B[i],
  dv$analytic[i], dv$finite_diff[i], dv$abs_diff[i]))
ad("\\bottomrule\\end{tabular}\\end{table}")
ad(sprintf(paste0("The maximum absolute discrepancy is $%.1e$. Two independent checks also pass: the ",
"B-spline basis satisfies partition of unity to $2.2\\times10^{-16}$, and the penalty has numerical rank ",
"8 of 10, matching the constant-plus-linear null space. The residualized treatment information ",
"$J(\\rho)=p^\\top M_\\lambda p$ ranges %.4f to %.4f against $J_0=6$, which reproduces the strategy's ",
"recorded manual-basis range of about 5.118 to 5.875. \\key{Gate 1 passes.}"),
 max(dv$abs_diff), min(dv$J_rho), max(dv$J_rho)))
ad("\\begin{figure}[h]\\centering\\includegraphics[width=\\textwidth]{fig1_derivative.pdf}",
"\\caption{Left: analytic and finite-difference derivatives coincide. Right: absolute discrepancy,",
"log scale; the dashed line marks $10^{-8}$.}\\end{figure}")

# ---------------- Task 3 ----------------
ad("\\section{Task 3: the diagnostic is stable in tolerance but \\key{not} in grid density}",
"\\paragraph{Definition.} For a tolerance $\\delta$, the near-optimal set and coefficient width are",
"\\begin{equation}\\mathcal L_e(\\delta)=\\Big\\{\\lambda\\in\\mathcal G:",
"\\tfrac{G_e(\\lambda)-G^{\\mathrm{grid}}_{e,\\min}}{G^{\\mathrm{grid}}_{e,\\min}}\\le\\delta\\Big\\},",
"\\qquad W_e(\\delta)=\\max_{\\lambda\\in\\mathcal L_e(\\delta)}\\widehat\\beta_{B,e}(\\lambda)",
"-\\min_{\\lambda\\in\\mathcal L_e(\\delta)}\\widehat\\beta_{B,e}(\\lambda).\\end{equation}",
"$\\mathcal G$ is a finite grid, so $W$ is a property of the grid as much as of the model. The",
"strategy anticipates this and asks that grid resolution be recorded. We measured it.")
ad("\\begin{table}[h]\\centering\\small",
"\\caption{Median $W_e(\\delta)$ over the 199 Eastings, and the count with $W_e\\ge0.25$, against grid density.}",
"\\begin{tabular}{rrrrrrrrr}\\toprule",
"& \\multicolumn{2}{c}{$\\delta=0.5\\%$} & \\multicolumn{2}{c}{$\\delta=1\\%$} &",
"\\multicolumn{2}{c}{$\\delta=2\\%$} & \\multicolumn{2}{c}{$\\delta=5\\%$}\\\\",
"\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\\cmidrule(lr){8-9}",
"grid pts & median & $n\\ge.25$ & median & $n\\ge.25$ & median & $n\\ge.25$ & median & $n\\ge.25$\\\\\\midrule")
for (g in sort(unique(fw$NGrid))) { q <- fw[fw$NGrid==g,]
  ad(sprintf("%d & %.4f & %d & %.4f & %d & %.4f & %d & %.4f & %d\\\\", g,
    median(q$W_0.5), sum(q$W_0.5>=.25), median(q$W_1), sum(q$W_1>=.25),
    median(q$W_2), sum(q$W_2>=.25), median(q$W_5), sum(q$W_5>=.25))) }
if (!is.null(f6)) ad(sprintf("600 & %.4f & %d & %.4f & %d & %.4f & %d & %.4f & %d\\\\",
  median(f6$W_0.5), sum(f6$W_0.5>=.25), median(f6$W_1), sum(f6$W_1>=.25),
  median(f6$W_2), sum(f6$W_2>=.25), median(f6$W_5), sum(f6$W_5>=.25)))
ad("\\bottomrule\\end{tabular}\\end{table}")
ad(sprintf(paste0("\\paragraph{This is a real problem for the diagnostic.} At $\\delta=1\\%%$ the median ",
"$W$ rises monotonically from %.4f to %.4f as the grid goes from 41 to 481 points, a factor of %.1f, ",
"and the count at $W\\ge0.25$ rises from %d to %d. It has \\emph{not} converged: between 241 and 481 ",
"points the median still rises by %.1f\\%%. $W$ approaches the supremum over a continuous near-optimal ",
"set from below, and slowly. Any reported value of $W$ is therefore meaningless without its grid, and ",
"two studies using different grids are not comparable."),
 median(fw$W_1[fw$NGrid==41]), median(fw$W_1[fw$NGrid==481]),
 median(fw$W_1[fw$NGrid==481])/max(median(fw$W_1[fw$NGrid==41]),1e-9),
 sum(fw$W_1[fw$NGrid==41]>=0.25), sum(fw$W_1[fw$NGrid==481]>=0.25),
 100*(median(fw$W_1[fw$NGrid==481])/median(fw$W_1[fw$NGrid==241])-1)))
if (!is.null(f6)) ad(sprintf(paste0("\\paragraph{The previously reported field figures reproduce.} ",
"On the 600-point Stage 3C grid the median $W_e(1\\%%)$ is %.4f with %d of 199 Eastings at $W\\ge0.25$, ",
"against the previously reported median $0.158$ and $70/199$. That confirms the earlier numbers and ",
"identifies the grid they came from."), median(f6$W_1), sum(f6$W_1>=0.25)))
# non-monotonicity under grid refinement
a41 <- fw[fw$NGrid==41,]; a481 <- fw[fw$NGrid==481,]
mg <- merge(a41, a481, by="Easting", suffixes=c("_41","_481"))
nbad <- sum(mg$W_1_481 < mg$W_1_41 - 1e-12)
ad(sprintf(paste0("\\paragraph{Worse: $W$ is not even monotone under refinement.} The 41-point grid ",
"is an \\emph{exact} subset of the 481-point grid, so a larger evaluated set could only widen the ",
"observed range -- if the admission rule were fixed. It is not. Refining the grid lowers ",
"$G^{\\mathrm{grid}}_{e,\\min}$, which is the reference point in the relative criterion ",
"$(G-G_{\\min})/G_{\\min}\\le\\delta$, so the threshold tightens and candidates admitted on the ",
"coarse grid can be excluded on the fine one. $G_{\\min}$ falls at all 199 Eastings, and at %d of them ",
"$W$ falls with it, by up to %.4f. At those locations the relative drop in $G_{\\min}$ averages ",
"%.3e, comparable to $\\delta$ itself. \\key{$W_e(\\delta)$ therefore cannot be described as ",
"converging to a limit from below; its reference point moves as the grid moves.} A grid-free ",
"definition would have to fix the reference by continuous minimisation first."),
 nbad, max(mg$W_1_41-mg$W_1_481),
 mean((mg$GCV_min_41[mg$W_1_481<mg$W_1_41-1e-12]-mg$GCV_min_481[mg$W_1_481<mg$W_1_41-1e-12])/
      mg$GCV_min_41[mg$W_1_481<mg$W_1_41-1e-12])))
ad("\\begin{figure}[h]\\centering\\includegraphics[width=\\textwidth]{fig2_field_W.pdf}",
"\\caption{Top: $W_e(1\\%)$ across the field on the densest grid. Bottom: median $W$ against grid",
"density at four tolerances; none has converged.}\\end{figure}")
# robustness subset table, appended before the verdict
SUB <- read.csv("OUT_subset.csv")
source("06b_report_part2.R", local = TRUE)
