# ROBUSTNESS OF THE NEGATIVE RESULT: look where the diagnostic should work best.
# If W only fails on average because most replicates have no smoothing ambiguity,
# it should still work in the subset that HAS ambiguity. This tests that.
BETA_TRUE <- 1.5
z <- do.call(rbind, lapply(list.files(".", pattern="^OUT_sim_.*\\.csv$"), read.csv))
z$err_auto <- abs(z$beta_auto - BETA_TRUE)
ev <- z[z$batch=="eval",]
auc <- function(x,a){ok<-is.finite(x);x<-x[ok];a<-a[ok];r<-rank(x);n1<-sum(a);n0<-sum(1-a)
  if(n1<5||n0<5) return(NA); (sum(r[a==1])-n1*(n1+1)/2)/(n1*n0)}
cat("multiple grid minima in", sum(ev$n_min>1), "of", nrow(ev), "evaluation replicates\n")
cat("inferior automatic (D>1e-4) in", sum(ev$D_regret>1e-4), "of", nrow(ev), "\n\n")
for (tau in c(0.25,0.50)) {
 cat(sprintf("=== tau = %.2f ===\n", tau))
 cat(sprintf("%-42s %7s %9s %9s %9s\n","subset","n","rate","AUC W(1%)","AUC SE"))
 subs <- list(
  "all evaluation replicates"              = rep(TRUE,nrow(ev)),
  "multiple detected grid minima"          = ev$n_min > 1,
  "inferior automatic selection (D>1e-4)"  = ev$D_regret > 1e-4,
  "W(1%) in top quartile"                  = ev$W_1 >= quantile(ev$W_1,0.75),
  "high noise only (sigma=3)"              = ev$sigma==3,
  "low noise only (sigma=1)"               = ev$sigma==1,
  "curved nuisance only"                   = ev$f=="curved",
  "AR(1) errors only"                      = ev$err=="ar1")
 for (nm in names(subs)) { s <- ev[subs[[nm]],]
  if (nrow(s) < 40) { cat(sprintf("%-42s %7d  (too small)\n", nm, nrow(s))); next }
  A <- as.numeric(s$err_auto > tau)
  cat(sprintf("%-42s %7d %9.3f %9s %9s\n", nm, nrow(s), mean(A),
    ifelse(is.na(auc(s$W_1,A)),"--",sprintf("%.4f",auc(s$W_1,A))),
    ifelse(is.na(auc(s$se_auto,A)),"--",sprintf("%.4f",auc(s$se_auto,A))))) }
 cat("\n")
}
cat("=== does W predict the error of the BEST-GRID estimate instead? ===\n")
for (tau in c(0.25,0.50)) {
  A <- as.numeric(abs(ev$beta_grid - BETA_TRUE) > tau)
  cat(sprintf("  tau=%.2f : AUC W(1%%) = %.4f ; AUC SE = %.4f\n", tau, auc(ev$W_1,A), auc(ev$se_auto,A)))
}
cat("\n=== is W just a noisier version of SE? partial Spearman ===\n")
rw <- rank(ev$W_1); rs <- rank(ev$se_auto); re <- rank(ev$err_auto)
r1 <- resid(lm(rw ~ rs)); r2 <- resid(lm(re ~ rs))
cat(sprintf("  Spearman(W, |err|) = %.4f ; after removing SE = %.4f\n",
    cor(ev$W_1, ev$err_auto, method="spearman"), cor(r1, r2)))

# save the subset table for the report
rows <- NULL
for (tau in c(0.25,0.50)) for (nm in names(subs)) { s <- ev[subs[[nm]],]
  if (nrow(s) < 40) next
  A <- as.numeric(s$err_auto > tau)
  rows <- rbind(rows, data.frame(tau=tau, subset=nm, n=nrow(s), rate=mean(A),
    auc_W=auc(s$W_1,A), auc_SE=auc(s$se_auto,A))) }
write.csv(rows, "OUT_subset.csv", row.names=FALSE)
