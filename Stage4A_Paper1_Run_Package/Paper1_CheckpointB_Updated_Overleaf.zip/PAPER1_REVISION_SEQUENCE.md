# Paper 1 — sequential revision register (Checkpoint B update)

## Checkpoint A — Stage 4A (complete)

- [x] 218 detected interior local minima refined; nine of nine validation checks passed.
- [x] Same 16 inferior automatic selections and same 199 regime classes as Stage 3C.
- [x] Stage 4A incorporated in Methods, Results, tables, and figures; compiled manuscript verified.

## Checkpoint B — remaining *core Paper 1* audit (completed to the extent supported by existing inputs)

- [x] Differentiate best 600-point grid, best alternative including refined minima and linear limit, and best evaluated including automatic, in both equations and a definitions table.
- [x] Add numerical comparison showing median auto–grid coefficient differences are not a substitute for verified optimizer discrepancies.
- [x] Audit cited Section 2 literature and limit novelty claims appropriately; correct mgcv documentation attribution.
- [x] Derive/use residualized-treatment relation and verify the original Stage 2 manual-basis design diagnostic (see `PAPER1_CHECKPOINT_B_AUDIT.md`).
- [x] Check original figure/table references, bibliography keys, Stage 3C vs Stage 4A captions, table values and source-data provenance.
- [x] Decide k=8/10/12 check is not a necessary gate for a paper explicitly conditional on k=10; it remains a potential supplement, not a result claimed here.
- [x] Recompile and inspect the updated PDF.
- [ ] Optional: execute the guarded `mgcv` version of the design diagnostic on a computer with R/mgcv (the actual mgcv penalty is distinct from the manually reconstructed basis).
- [ ] Confirm author names/affiliations and target journal. These cannot be inferred from the supplied research data; retain placeholders.

## Checkpoint C — reviewer analysis (DEFERRED until user authorizes)

- [ ] Audit complete smoothing-ladder run outputs and data-generation scripts.
- [ ] Verify raw/processed provenance and first-stage smoothing details.
- [ ] Decide which justified sensitivity findings enter main paper, supplement or limitations.
- [ ] Preserve the original fixed-input numerical results as the reference case.

## Checkpoint D — manuscript completion

- [ ] Section 6 Discussion and limitations after Checkpoint C.
- [ ] Section 7 Conclusion and final contribution statement.
- [ ] Final bibliography/build/proofread, author/journal metadata and submission archive.

No separate theoretical stationary-root investigation is in scope for Paper 1.
