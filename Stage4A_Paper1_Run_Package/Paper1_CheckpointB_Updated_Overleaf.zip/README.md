# Paper 1 — Checkpoint B updated manuscript (November 8, 2026)

This is an **updated research manuscript checkpoint**, not the finished journal-submission draft. It begins with the original Stage 1–3C curated manuscript and integrates the validated Stage 4A local-minimum refinements followed by the **core Paper 1 Checkpoint B audit**. No reviewer raw-versus-processed or smoothing-ladder findings are included.

## Compile / inspect

Upload this whole ZIP as an Overleaf project and use `main.tex` as the main document. Compile with **pdfLaTeX**, bibliography backend **Biber**. A compiled `main.pdf` is included. The source folder `source_data/` provides the numerical tables and the pass-level 214 reference dataset for the supplemental design diagnostic.

## New in Checkpoint B

- Explicit nomenclature table in `tables/checkpointB_reference_sets.tex` separating Stage 3C grid, Stage 4A best alternative (excluding automatic), and Stage 4A best evaluated (including automatic).
- Correctly separated automatic–grid, automatic–alternative, automatic–best-evaluated, and automatic–linear product coefficients in the Results, including independently verified 199-Easting medians.
- Direct check of `p^T M_lambda p` for the Stage 2 **manual spline** at the fixed 24-pass design. Reproduction code: `scripts/checkpointB_manual_design_check.py`, original pass-level reference: `source_data/Example1SmoothHarvestStrip214.csv`, and full numerical trace: `source_data/CheckpointB_Manual_Residualized_Treatment_Diagnostic.csv`. External Python packages: NumPy, pandas and SciPy (`pip install -r scripts/requirements.txt`).
- Optional, **unexecuted** `scripts/checkpointB_mgcv_design_diagnostic.R` for the distinct GAM basis; requires R plus `mgcv`. It incorporates coefficient-reproduction checks and must not be treated as results until it passes on an R computer.
- Literature scope clarification; more directly grounded local-minima citations and a corrected `mgcv` documentation attribution.
- Verified table and figure references and preserved all original exhibits; no Stage 1–4A numerical results were replaced.

## Boundaries

- Stage 4A refines pre-detected minima only; its 16 inferior automatic selections are validated comparisons to **evaluated alternatives**, not proof of the mathematically global GCV optimum.
- `Stage4A_Full_Run.R` still requires the complete original processed `Example1SmoothHarvestPasses.csv` to rerun the GAMs; that full 4,776-row data file is not in this archive.
- No new `k=8,10,12` GAM experiment has been run. Paper 1's reported results are conditional on the specified `k=10` model. Expanded second-stage basis sensitivity remains optional.
- Reviewer first-stage preprocessing analysis remains a placeholder; Sections 6 and 7 remain placeholders for the later synthesis.
- Author information and target journal formatting await confirmation.

See `PAPER1_CHECKPOINT_B_AUDIT.md` and `PAPER1_REVISION_SEQUENCE.md` for completed checks and remaining items.
