"""Rebuild Stage 2 manuscript figures from saved completed Stage 2 CSV outputs.

No GAM fits are performed. Run in the Overleaf project root:
    python -m pip install -r scripts/requirements.txt
    python scripts/build_stage2_figures.py
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.ticker import MultipleLocator

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'source_data'
OUT=ROOT/'figures'
OUT.mkdir(exist_ok=True)
grid=pd.read_csv(DATA/'Manual_Full_Field_Grid.csv')
sumdf=pd.read_csv(DATA/'Manual_Full_Field_Summary.csv').sort_values('Easting').reset_index(drop=True)
cands=pd.read_csv(DATA/'Manual_Candidate_Minima.csv')
E=sumdf.Easting.to_numpy()
LOG=np.sort(grid.log_lambda.unique())
assert len(E)==199 and len(LOG)==400 and len(grid)==199*400
assert grid.groupby('Easting').size().eq(400).all()
absG=grid.pivot(index='Easting',columns='log_lambda',values='GCV').sort_index().to_numpy()
lim=sumdf.GCV_Linear_Limit.to_numpy()
relG=absG-lim[:,None]
plt.rcParams.update({
 'font.family':'DejaVu Sans', 'font.size':9.3, 'axes.labelsize':9.5,
 'axes.titlesize':10.5,'legend.fontsize':8,'xtick.labelsize':8.5,
 'ytick.labelsize':8.5,'pdf.fonttype':42,'ps.fonttype':42,
 'savefig.bbox':'tight','figure.dpi':130
})

def save(fig,base):
    fig.savefig(OUT/(base+'.pdf'),bbox_inches='tight',pad_inches=.1)
    fig.savefig(OUT/(base+'.png'),dpi=180,bbox_inches='tight',pad_inches=.1)
    plt.close(fig)

def axis_finish(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.tick_params(direction='out',length=3)

# Figure 1: manual absolute/relative heatmaps. Both share exactly the same data grid.
fig,axs=plt.subplots(1,2,figsize=(8.4,3.55),layout='constrained',sharey=True)
extent=(LOG[0],LOG[-1],E[0],E[-1])
im=axs[0].imshow(absG,origin='lower',extent=extent,aspect='auto',cmap='viridis',vmin=absG.min(),vmax=absG.max(),interpolation='nearest')
fig.colorbar(im,ax=axs[0],shrink=.88,pad=.025,label='Absolute GCV')
axs[0].set_title('(a) Uncentered GCV score')
scale=TwoSlopeNorm(vmin=float(np.nanmin(relG)),vcenter=0,vmax=float(np.nanmax(relG)))
im2=axs[1].imshow(relG,origin='lower',extent=extent,aspect='auto',cmap='RdBu_r',norm=scale,interpolation='nearest')
fig.colorbar(im2,ax=axs[1],shrink=.88,pad=.025,label='GCV minus linear-limit GCV')
axs[1].set_title('(b) Relative to the exact linear limit')
for ax in axs:
 ax.set_xlabel(r'$\ell=\log(\lambda_{\rm manual})$'); ax.set_xticks([0,5,10,15,20]); ax.set_yticks([50,150,250,350])
axs[0].set_ylabel('Easting')
save(fig,'stage2_gcv_landscape')

# Figure 2: three original slices and their exact linear GCV asymptotes.
fig,axs=plt.subplots(1,3,figsize=(9.1,2.9),layout='constrained')
for e,ax in zip((214,216,218),axs):
 d=grid.loc[grid.Easting.eq(e)].sort_values('log_lambda')
 s=sumdf.loc[sumdf.Easting.eq(e)].iloc[0]
 ax.plot(d.log_lambda,d.GCV,color='#224f75',lw=1.85,label='Finite-$\\lambda$ GCV')
 ax.axhline(s.GCV_Linear_Limit,ls='--',lw=1.0,color='#bc5c40',label='Exact linear-limit GCV')
 cs=cands[(cands.Easting.eq(e)) & (cands.Candidate.eq('interior_refined'))]
 if len(cs): ax.scatter(cs.log_lambda,cs.GCV,color='#ab542c',s=21,zorder=3,label='Refined interior minimum')
 ax.set_title(f'Easting {e}'); ax.set_xlabel(r'$\log(\lambda_{\rm manual})$')
 ax.set_xlim(-1,23);ax.xaxis.set_major_locator(MultipleLocator(5));axis_finish(ax)
axs[0].set_ylabel('Absolute GCV')
handles,labels=axs[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='outside upper center',ncol=3,frameon=False,bbox_to_anchor=(0.5,1.07))
save(fig,'stage2_three_slices')

# Figure 3: location and count of multiple minima.
fig,ax=plt.subplots(figsize=(8.4,2.8),layout='constrained')
ct=sumdf.Interior_Dip_Count.to_numpy()
ax.vlines(E,0,ct,color='#365e83',linewidth=0.85)
ax.scatter(E[ct>=2],ct[ct>=2],s=12,color='#a35335',zorder=4,label='At least two detected minima')
ax.axhline(1,color='0.73',ls=':',lw=.85)
ax.set_xlim(0,400);ax.set_ylim(-.08,3.3);ax.set_xlabel('Easting');ax.set_ylabel('Detected interior minima');ax.set_yticks([0,1,2,3]);ax.legend(loc='upper right',frameon=False)
axis_finish(ax)
save(fig,'stage2_minima_locations')

# Figure 4: manual structural contrast & regime strip. Does NOT connect across NA candidates.
fig,(ax0,ax1)=plt.subplots(2,1,figsize=(8.4,4.05),height_ratios=[.55,2.35],sharex=True,layout='constrained')
line=(sumdf.Lowest_Candidate=='linear_limit').to_numpy()
ax0.scatter(E[~line],np.zeros((~line).sum()),s=14,marker='s',color='#42668b',label='Interior candidate')
ax0.scatter(E[line],np.zeros(line.sum()),s=14,marker='s',color='#b56e35',label='Exact linear limit')
ax0.set_yticks([]);ax0.set_ylim(-.6,.6);ax0.set_title('Preferred candidate classification by Easting',fontsize=9.6,pad=6)
ax0.legend(loc='upper right',frameon=False,ncol=2,fontsize=7.9)
ax0.spines['left'].set_visible(False);ax0.spines['top'].set_visible(False);ax0.spines['right'].set_visible(False)
vals=sumdf.Structural_Gap_Interior_Minus_Linear.to_numpy()
ax1.scatter(E,vals,s=9,c=np.where(vals>0,'#b56e35','#42668b'))
ax1.axhline(0,ls='--',color='0.3',lw=1)
ax1.set_ylabel('Best interior GCV $-$ exact linear GCV')
ax1.set_xlabel('Easting');ax1.set_xlim(0,400)
axis_finish(ax1)
save(fig,'stage2_structural_preference')

# Figure 5: coefficient trajectories across Easting and same-model linear limit.
fig,ax=plt.subplots(figsize=(8.4,3.05),layout='constrained')
ax.plot(E,sumdf.Lowest_Candidate_Product_B,color='#2d587b',lw=1.75,label='Lowest listed manual GCV candidate')
ax.plot(E,sumdf.Product_B_Linear_Limit,color='#ae6842',lw=1.45,ls='--',label='Exact linear-limit estimate')
ax.set_ylabel('Estimated Product B coefficient');ax.set_xlabel('Easting');ax.set_xlim(0,400)
ax.legend(loc='upper left',frameon=False)
axis_finish(ax)
save(fig,'stage2_product_trajectory')
print('Wrote five source-derived Stage 2 figure pairs to',OUT)
