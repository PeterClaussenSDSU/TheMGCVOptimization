#!/usr/bin/env python3
"""Rebuild manuscript Stage 3A–3C figures and tables from completed source CSVs.

Run: python -m pip install pandas numpy matplotlib
     python scripts/build_stage3_exhibits.py
No GAM fitting or stationary-point refinement is done here.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'source_data'; FIG=ROOT/'figures'; TAB=ROOT/'tables'
FIG.mkdir(exist_ok=True); TAB.mkdir(exist_ok=True)
a=pd.read_csv(DATA/'Stage3A_Auto_vs_Grid.csv')
agd=pd.read_csv(DATA/'Stage3A_Fixed_Grid.csv')
b=pd.read_csv(DATA/'Stage3B_Linear_Screen_and_Trajectories.csv')
c=pd.read_csv(DATA/'Stage3C_Auto_vs_Grid.csv')
g=pd.read_csv(DATA/'Stage3C_Full_Grid.csv')
d=pd.read_csv(DATA/'Stage3C_Interior_Grid_Dips.csv')
m=pd.read_csv(DATA/'Manual_Full_Field_Summary.csv')
assert len(a)==6 and len(agd)==3600 and len(b)==199 and len(c)==199 and len(g)==119400 and len(d)==218
assert np.array_equal(b.Easting,c.Easting)
assert np.max(np.abs(b.GCV-c.Automatic_GCV)) < 1e-8
assert int(c.Auto_Worse_Than_Grid.sum())==16 and int(c.Auto_Worse_Than_Linear.sum())==6
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'legend.fontsize':7.8,'figure.dpi':130,'savefig.dpi':160, 'pdf.fonttype':42})
COLOR_A='#b04f45'; COLOR_G='#306aa2'; COLOR_L='#5c646e'; COLOR_I='#d29a42'

def save(fig,basename):
 fig.savefig(FIG/f'{basename}.pdf',bbox_inches='tight',pad_inches=.09)
 fig.savefig(FIG/f'{basename}.png',bbox_inches='tight',pad_inches=.09)
 plt.close(fig)

# Figure A: Six-pilot absolute-GCV profiles: auto parameter may lie beyond fixed grid.
fig,axs=plt.subplots(3,2,figsize=(10.4,9.1),sharex=True,constrained_layout=True)
for ax, (e, p) in zip(axs.flat,a.iterrows()):
 e=int(p.Easting); sub=agd[agd.Easting==e]
 ax.plot(sub.LogLambda,sub.GCV,color=COLOR_G,linewidth=1.4,label='Fixed grid')
 ax.scatter([p.Automatic_LogLambda],[p.Automatic_GCV],color=COLOR_A,marker='x',s=64,linewidths=1.7,zorder=4,label='Automatic')
 ax.scatter([p.Best_Grid_LogLambda],[p.Best_Grid_GCV],s=24,facecolors=COLOR_I,edgecolors='#60440e',zorder=5,label='Lowest grid')
 ax.set_title(f'Easting {e}  |  auto - grid GCV: {p.Optimizer_GCV_Gap:+.3f}')
 ax.set_xlabel(r'log($\lambda_{\mathrm{mgcv}}$)')
 ax.set_ylabel('Absolute GCV')
 ax.set_xlim(-12,31)
 ax.grid(alpha=.16,linewidth=.6)
axs[0,0].legend(loc='best',frameon=False)
save(fig,'stage3A_pilot_gcv_profiles')

# Figure B: Stage 3B coefficients / linear benchmark and detect six positive gaps
fig,axs=plt.subplots(2,1,figsize=(9.8,6.5),sharex=True,constrained_layout=True,gridspec_kw={'height_ratios':[1.45,1]})
axs[0].plot(b.Easting,b.Product_B,color=COLOR_A,linewidth=1.4,label='Automatic mgcv')
axs[0].plot(b.Easting,b.Linear_Product_B,color=COLOR_L,linestyle='--',linewidth=1.4,label='Exact linear limit')
axs[0].set_ylabel('Adjusted Product B coefficient')
axs[0].legend(frameon=False)
axs[1].plot(b.Easting,b.Auto_Minus_Linear_GCV,color='#424b54',lw=1.2)
positive=b[b.Worse_Than_Linear]
axs[1].scatter(positive.Easting,positive.Auto_Minus_Linear_GCV,facecolor=COLOR_A,s=25,zorder=5,label='Automatic GCV > linear GCV')
axs[1].axhline(0,color='gray',lw=.9,ls=':')
axs[1].set_ylabel('GCV(auto) - GCV(linear)')
axs[1].set_xlabel('Easting')
axs[1].legend(frameon=False)
for ax in axs:ax.grid(alpha=.12)
save(fig,'stage3B_automatic_linear_screen')

# Figure C: automatic lambda and complexity, make the mgcv scale explicit
fig,axs=plt.subplots(2,1,figsize=(9.8,6.2),sharex=True,constrained_layout=True)
axs[0].plot(b.Easting,b.LogLambda,color=COLOR_A,lw=1.6)
axs[0].set_ylabel(r'Automatic log($\lambda_{\mathrm{mgcv}}$)')
axs[1].plot(b.Easting,b.Smooth_EDF,color=COLOR_G,lw=1.6)
axs[1].axhline(1,color=COLOR_L,ls='--',lw=1,label='Linear-nullspace smooth EDF = 1')
axs[1].set_ylabel('Northing smooth EDF')
axs[1].set_xlabel('Easting')
axs[1].legend(loc='best',frameon=False)
for ax in axs:ax.grid(alpha=.14)
save(fig,'stage3B_smoothing_trajectory')

# Figure D: Full-field absolute and within-Easting relative score landscapes.
P=g.pivot(index='Easting',columns='LogLambda',values='GCV').sort_index().sort_index(axis=1)
E=c.set_index('Easting').loc[P.index,'Exact_Linear_GCV'].to_numpy()
rel=P.to_numpy()-E[:,None]
X=P.columns.to_numpy(dtype=float); Y=P.index.to_numpy(dtype=float)
fig,axs=plt.subplots(1,2,figsize=(11.2,4.15),constrained_layout=True)
im=axs[0].imshow(P.to_numpy(),aspect='auto',origin='lower',extent=[X[0],X[-1],Y[0],Y[-1]],cmap='viridis',vmin=P.min().min(),vmax=P.max().max())
axs[0].set_title('Absolute GCV (mgcv)')
fig.colorbar(im,ax=axs[0],fraction=.046,pad=.02,label='GCV score')
# Full observed range, no implicit colorbar clipping.
minr,maxr=np.nanmin(rel),np.nanmax(rel)
im2=axs[1].imshow(rel,aspect='auto',origin='lower',extent=[X[0],X[-1],Y[0],Y[-1]],cmap='coolwarm',norm=TwoSlopeNorm(vmin=minr,vcenter=0,vmax=maxr))
axs[1].set_title('GCV - exact linear-limit GCV')
fig.colorbar(im2,ax=axs[1],fraction=.046,pad=.02,label='Within-Easting difference')
for ax in axs:
 ax.set_xlabel(r'log($\lambda_{\mathrm{mgcv}}$)')
 ax.set_ylabel('Easting')
save(fig,'stage3C_gcv_landscapes')

# Figure E: systematic mismatch of criterion and coefficient effects
fig,axs=plt.subplots(2,1,figsize=(10,6.6),sharex=True,constrained_layout=True)
axs[0].axhline(0,color='gray',lw=.8)
axs[0].vlines(c.Easting,0,c.Auto_Minus_Best_Grid_GCV,color='#a2abb2',lw=.7)
flag=c[c.Auto_Worse_Than_Grid]
axs[0].scatter(flag.Easting,flag.Auto_Minus_Best_Grid_GCV,color=COLOR_A,s=24,label='16 inferior automatic selections',zorder=3)
axs[0].set_ylabel('GCV(auto) - GCV(best grid)')
axs[0].legend(frameon=False,loc='upper left')
axs[1].axhline(0,color='gray',lw=.8)
axs[1].vlines(c.Easting,0,c.Auto_Minus_Best_Grid_Beta,color='#a2abb2',lw=.7)
axs[1].scatter(flag.Easting,flag.Auto_Minus_Best_Grid_Beta,color=COLOR_A,s=24)
axs[1].set_ylabel(r'$\hat\beta_B$(auto) - $\hat\beta_B$(best grid)')
axs[1].set_xlabel('Easting')
for ax in axs: ax.grid(alpha=.12)
save(fig,'stage3C_optimizer_and_coefficient_gaps')

# Figure F: all three aligned coefficient contrasts
fig,ax=plt.subplots(figsize=(10.4,4.7),constrained_layout=True)
ax.plot(c.Easting,c.Automatic_Product_B,color=COLOR_A,lw=1.8,label='Automatic mgcv')
ax.plot(c.Easting,c.Best_Grid_Product_B,color=COLOR_G,lw=1.2,linestyle='--',label='Lowest 600-point grid')
ax.plot(c.Easting,c.Exact_Linear_Product_B,color=COLOR_L,lw=1.2,linestyle=':',label='Exact linear limit')
ax.set_xlabel('Easting');ax.set_ylabel('Adjusted Product B coefficient')
ax.legend(loc='upper left',frameon=False,ncol=2)
ax.grid(alpha=.14)
save(fig,'stage3C_product_trajectories')

# Figure G: full-field minima count (manual and mgcv) and geographic points of mgcv multi minima
counts0=m.Interior_Dip_Count.value_counts().reindex([0,1,2,3],fill_value=0)
counts1=c.Interior_Grid_Dip_Count.value_counts().reindex([0,1,2,3],fill_value=0)
fig,axs=plt.subplots(2,1,figsize=(9.6,6.4),constrained_layout=True,gridspec_kw={'height_ratios':[1,1.15]})
x=np.arange(4)
axs[0].bar(x-.17,counts0.values,width=.34,color=COLOR_G,label='Manual Stage 2')
axs[0].bar(x+.17,counts1.values,width=.34,color=COLOR_A,label='mgcv Stage 3C')
axs[0].set_xticks(x,[str(k) for k in x])
axs[0].set_ylabel('Number of Eastings');axs[0].set_xlabel('Detected interior minima')
axs[0].legend(frameon=False)
axs[1].vlines(c.Easting,0,c.Interior_Grid_Dip_Count,color='#9da6ad',linewidth=.9)
ml=c[c.Interior_Grid_Dip_Count>=2]
axs[1].scatter(ml.Easting,ml.Interior_Grid_Dip_Count,c=COLOR_A,s=23,zorder=5,label='Multiple-minimum profiles')
axs[1].set_ylim(-.15,3.45)
axs[1].set_yticks([0,1,2,3]);axs[1].set_xlabel('Easting');axs[1].set_ylabel('mgcv interior minima')
axs[1].legend(loc='upper right',frameon=False)
save(fig,'stage3C_minimum_counts_and_locations')

# Figure H: two very different inferior automatic solutions at 216 and 374
fig,axs=plt.subplots(1,2,figsize=(10.8,4.45),constrained_layout=True)
for ax,e in zip(axs,[216,374]):
 sub=g[g.Easting==e]; pp=c.set_index('Easting').loc[e]; dips=d[d.Easting==e]
 ax.plot(sub.LogLambda,sub.GCV,color=COLOR_G,lw=1.55,label='Fixed-grid GCV')
 ax.scatter([pp.Automatic_LogLambda],[pp.Automatic_GCV],s=65,marker='x',color=COLOR_A,linewidths=2.1,zorder=6,label='Automatic solution')
 ax.scatter([pp.Best_Grid_LogLambda],[pp.Best_Grid_GCV],s=38,facecolor=COLOR_I,edgecolor='#5d491e',zorder=7,label='Lowest grid candidate')
 ax.scatter(dips.LogLambda,dips.GCV,facecolors='none',edgecolors=COLOR_G,s=40,zorder=5,label='Detected interior minima')
 ax.axhline(pp.Exact_Linear_GCV,color=COLOR_L,linestyle=':',lw=1.1,label='Exact linear limit')
 ax.set_title(f'Easting {e}: GCV gap = {pp.Auto_Minus_Best_Grid_GCV:.3f}')
 ax.set_xlabel(r'log($\lambda_{\mathrm{mgcv}}$)');ax.set_ylabel('Absolute GCV')
 ax.set_xlim(-12,27)
 ax.grid(alpha=.14)
axs[1].legend(frameon=False,loc='lower right',fontsize=7)
save(fig,'stage3C_contrasting_gcv_profiles')

# Tables: render TeX source directly from primary CSV.
def texwrite(fname,body): (TAB/fname).write_text(body,encoding='utf-8')

def fl(v,p=3):
 if abs(v)<0.0005 and p==3:return '$\\approx 0$'
 return f'{v:.{p}f}'

rows=[]
for r in a.itertuples(index=False):
 rows.append(f'{int(r.Easting)} & {r.Automatic_GCV:.3f} & {r.Best_Grid_GCV:.3f} & {r.Optimizer_GCV_Gap:+.3f} & {r.Product_B_Difference:+.3f} \\\\')
texwrite('stage3A_pilot_comparison.tex',r'''\begin{table}[tbp]
\centering\small
\caption{Stage 3A pilot: automatic GCV selection versus a fixed 600-point smoothing-parameter grid. The displayed differences are automatic minus lowest grid. Small negative gaps reflect the finite spacing of the grid rather than a failure of the automatic fit. Source: \texttt{Stage3A\_Auto\_vs\_Grid.csv}.}
\label{tab:stage3A-pilot}
\begin{tabular}{rrrrr}\toprule
Easting & Automatic GCV & Lowest-grid GCV & GCV gap & Product B gap \\
\midrule
'''+ '\n'.join(rows)+r'''
\bottomrule\end{tabular}
\end{table}
''')
rows=[]
for r in c[c.Auto_Worse_Than_Grid].itertuples(index=False):
 rows.append(f'{int(r.Easting)} & {r.Auto_Minus_Best_Grid_GCV:+.3f} & {r.Auto_Minus_Best_Grid_Beta:+.3f} & {int(r.Interior_Grid_Dip_Count)} \\\\')
texwrite('stage3C_inferior_selections.tex',r'''\begin{table}[tbp]
\centering\small
\caption{All Eastings where the automatic \texttt{mgcv} score exceeded the lowest score on the 600-point fixed grid by more than $10^{-4}$. Differences equal automatic minus lowest grid. The final column counts qualifying interior grid minima, not exact theoretical stationary points. Source: \texttt{Stage3C\_Auto\_vs\_Grid.csv}.}
\label{tab:stage3C-inferior}
\begin{tabular}{rrrr}\toprule
Easting & GCV gap & Product B coefficient gap & Interior minima \\
\midrule
'''+ '\n'.join(rows)+r'''
\bottomrule\end{tabular}
\end{table}
''')
rows=[]
for k in range(4):
 rows.append(f'{k} & {int(counts0[k])} & {int(counts1[k])} \\\\')
texwrite('stage3C_minima_counts.tex',r'''\begin{table}[tbp]
\centering
\caption{Distribution of grid-detected interior GCV minima across 199 Eastings. The manual spline used 400 log-smoothing values and local three-point refinement; the \texttt{mgcv} experiment used 600 fixed values and counted grid turning points. Their bases and penalty scales differ. Sources: \texttt{Manual\_Full\_Field\_Summary.csv} and \texttt{Stage3C\_Auto\_vs\_Grid.csv}.}
\label{tab:stage3C-minima}
\begin{tabular}{rrr}\toprule
Detected minima & Manual Stage 2 & \texttt{mgcv} Stage 3C \\
\midrule
'''+ '\n'.join(rows)+r'''
\midrule
Total Eastings & 199 & 199 \\
Eastings with multiple minima & 27 & 28 \\
\bottomrule\end{tabular}
\end{table}
''')
rows=[]
for e in (174,374):
 r=c.set_index('Easting').loc[e]
 rows.append(f'{e} & {r.Auto_Minus_Best_Grid_GCV:+.3f} & {r.Auto_Minus_Best_Grid_Beta:+.3f} & {int(r.Interior_Grid_Dip_Count)} \\\\')
texwrite('stage3C_contrasts.tex',r'''\begin{table}[tbp]
\centering\small
\caption{Contrasting score and treatment-coefficient sensitivity. A larger GCV shortfall need not correspond to a larger change in the unpenalized Product B estimate. Differences equal automatic minus lowest evaluated grid. Source: \texttt{Stage3C\_Auto\_vs\_Grid.csv}.}
\label{tab:stage3C-contrasts}
\begin{tabular}{rrrr}\toprule
Easting & GCV gap & Product B gap & Interior minima \\
\midrule
'''+ '\n'.join(rows)+r'''
\bottomrule\end{tabular}
\end{table}
''')
print('Wrote Stage3A-C figures and tables from completed CSVs; no model refits.\n', 'Figures:', len(list(FIG.glob('stage3*.pdf'))), 'Tables:',len(list(TAB.glob('stage3*.tex'))))
