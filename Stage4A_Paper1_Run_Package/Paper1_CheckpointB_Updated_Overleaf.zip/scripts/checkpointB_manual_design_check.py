import numpy as np, pandas as pd
from scipy.interpolate import BSpline
from scipy.linalg import null_space
from numpy.polynomial.legendre import leggauss
from pathlib import Path
root=Path(__file__).resolve().parent.parent
d=pd.read_csv(root/'source_data/Example1SmoothHarvestStrip214.csv').sort_values('PassNo')
x=d.Northing.to_numpy(); p=(d.Product=='B').astype(float).to_numpy(); y=d.Yield.to_numpy(); n=len(x)
lo, hi=x.min(),x.max(); degree=3;k=10;n_int=k-degree-1
hk=(hi-lo)/(n_int+1)
t=np.r_[lo-hk*np.arange(degree,0,-1), lo+hk*np.arange(n_int+2), hi+hk*np.arange(1,degree+1)]
assert len(t)==14
spl=[BSpline(t,np.eye(k)[i],degree) for i in range(k)]
B=np.stack([s(x) for s in spl],axis=1)
assert np.max(np.abs(B.sum(axis=1)-1))<1e-10
edges=t[(t>=lo-1e-9)&(t<=hi+1e-9)]
S=np.zeros((k,k)); nodes,weights=leggauss(4)
for left,right in zip(edges[:-1],edges[1:]):
    points=(left+right)/2+(right-left)/2*nodes
    deriv=np.stack([s.derivative(2)(points) for s in spl],axis=1)
    S+=deriv.T@np.diag((right-left)/2*weights)@deriv
Z=null_space(B.sum(axis=0).reshape(1,-1)); Bc=B@Z; Sc=Z.T@S@Z
X=np.column_stack([np.ones(n),p,Bc]); Pen=np.zeros((11,11));Pen[2:,2:]=Sc
W=np.delete(X,1,axis=1); Sw=np.delete(np.delete(Pen,1,axis=0),1,axis=1)
reference=pd.read_csv(root/'source_data/Manual_Full_Field_Grid.csv'); reference=reference[reference.Easting==214].reset_index(drop=True)
records=[]
for row in reference.itertuples():
    lam=row._3 if False else np.exp(row.log_lambda)
    full=np.linalg.solve(X.T@X+lam*Pen,X.T@y)
    pred=X@full
    H=X@np.linalg.solve(X.T@X+lam*Pen,X.T)
    score=24*np.sum((y-pred)**2)/(24-np.trace(H))**2
    mw_p=p-W@np.linalg.solve(W.T@W+lam*Sw,W.T@p)
    info=p@mw_p
    bpt=(p@(y-W@np.linalg.solve(W.T@W+lam*Sw,W.T@y)))/info
    records.append([row.log_lambda,score,full[1],bpt,info,np.trace(H)])
out=pd.DataFrame(records, columns=['LogLambda','GCV_Reconstructed','Beta_Reconstructed','Beta_Partialled','Residualized_Treatment_Information','Total_EDF_Reconstructed'])
print('Max abs GCV diff',np.max(abs(reference.GCV.to_numpy()-out.GCV_Reconstructed.to_numpy())))
print('Max abs beta diff',np.max(abs(reference.Product_B.to_numpy()-out.Beta_Reconstructed.to_numpy())))
print('Max abs partial beta error',np.max(abs(out.Beta_Partialled-out.Beta_Reconstructed)))
print('Min info',out.Residualized_Treatment_Information.min(),'max',out.Residualized_Treatment_Information.max())
print('LogLambda where minimum',out.loc[out.Residualized_Treatment_Information.idxmin(),['LogLambda','Residualized_Treatment_Information']].to_dict())
print('LogLambda where maximum',out.loc[out.Residualized_Treatment_Information.idxmax(),['LogLambda','Residualized_Treatment_Information']].to_dict())
print(out.iloc[[0,50,100,175,250,399]][['LogLambda','Residualized_Treatment_Information','Beta_Partialled','Total_EDF_Reconstructed']].to_string(index=False))
out.to_csv(root/'source_data/CheckpointB_Manual_Residualized_Treatment_Diagnostic.csv',index=False)
