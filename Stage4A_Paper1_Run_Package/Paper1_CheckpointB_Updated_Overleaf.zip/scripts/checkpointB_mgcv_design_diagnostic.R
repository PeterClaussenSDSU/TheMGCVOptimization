# Checkpoint B OPTIONAL verification for the actual mgcv basis.
# This script is not needed to compile Paper 1. Run from the Overleaf-project
# root (where source_data/ exists) on a computer with R and mgcv installed.
# It does NOT change the Stage 3C or Stage 4A results.
# External package: mgcv. All other functions below are Base R.
# install.packages("mgcv")    # first time only
if (!requireNamespace("mgcv", quietly = TRUE)) stop("Install mgcv first")

f <- file.path(getwd(), "source_data", "Example1SmoothHarvestStrip214.csv")
if (!file.exists(f)) stop("Set working directory to the project root")
d <- read.csv(f, stringsAsFactors = FALSE)
d <- d[order(d$PassNo), , drop = FALSE]
d$Product <- factor(trimws(d$Product), levels = c("E", "B"))
stopifnot(nrow(d) == 24, sum(d$Product == "B") == 12)

log_sp <- c(-12, -6, -3.352, 0, 2.145, 6, 12, 20, 25)
results <- vector("list", length(log_sp))
for (i in seq_along(log_sp)) {
  sp_input <- exp(log_sp[i])
  fit <- mgcv::gam(
    Yield ~ Product + s(Northing, bs = "bs", k = 10, m = c(3, 2)),
    data = d, family = gaussian(), method = "GCV.Cp", sp = sp_input
  )
  X <- predict(fit, type = "lpmatrix")
  idx_p <- match("ProductB", colnames(X))
  stopifnot(!is.na(idx_p), length(fit$smooth) == 1,
            length(fit$smooth[[1]]$S) == 1)
  P <- matrix(0, ncol(X), ncol(X))
  id_s <- fit$smooth[[1]]$first.para:fit$smooth[[1]]$last.para
  P[id_s, id_s] <- fit$sp[1] * fit$smooth[[1]]$S[[1]]

  # Safety gate: the reconstructed normal equations must reproduce the mgcv
  # fitted coefficient vector BEFORE the residualized-treatment diagnostic
  # is accepted. Some mgcv versions may use reparameterizations or scaling;
  # if verification fails, inspect the internal penalty representation.
  b_reconstructed <- as.vector(solve(crossprod(X) + P, crossprod(X, d$Yield)))
  err_coef <- max(abs(b_reconstructed - as.numeric(coef(fit))))
  if (!is.finite(err_coef) || err_coef >= 1e-5)
    stop(sprintf("Penalty verification failed at log(sp)=%.4f: error=%.4g", log_sp[i], err_coef))

  p <- as.vector(X[, idx_p])
  W <- X[, -idx_p, drop = FALSE]
  S_W <- P[-idx_p, -idx_p, drop = FALSE]
  K_W <- crossprod(W) + S_W
  Mp <- p - as.vector(W %*% solve(K_W, crossprod(W, p)))
  My <- d$Yield - as.vector(W %*% solve(K_W, crossprod(W, d$Yield)))
  residual_info <- sum(p * Mp)
  beta_partial <- sum(p * My) / residual_info
  err_partial <- abs(beta_partial - unname(coef(fit)["ProductB"]))
  if (!is.finite(err_partial) || err_partial >= 1e-5)
    stop(sprintf("Partialled coefficient check failed at log(sp)=%.4f", log_sp[i]))

  results[[i]] <- data.frame(
    LogSP = log_sp[i], SP = sp_input,
    Residualized_Product_Design = residual_info,
    Product_B = unname(coef(fit)["ProductB"]),
    Total_EDF = sum(fit$edf),
    Coefficient_Reconstruction_Error = err_coef,
    Partialled_Coefficient_Error = err_partial
  )
}
result <- do.call(rbind, results)
print(result, row.names = FALSE, digits = 9)
out <- file.path(getwd(), "checkpointB_mgcv_design_diagnostic_OUTPUT.csv")
write.csv(result, out, row.names = FALSE)
cat("Verified mgcv design diagnostic written to", out, "\n")
