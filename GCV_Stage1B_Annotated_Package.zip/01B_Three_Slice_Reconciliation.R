# STAGE 1B — Three Slice Reconciliation (standalone Base R script)
# See .qmd or .Rmd for mathematical and line-by-line explanations.

# All Stage 1B numerical operations use Base R. No library() call.
data_dir <- "C:/Users/pbbs/Claussen"

full_file <- file.path(data_dir, "Example1SmoothHarvestPasses.csv")
reference_eastings <- c(214, 216, 218)
reference_files <- file.path(
  data_dir,
  paste0("Example1SmoothHarvestStrip", reference_eastings, ".csv")
)

output_dir <- file.path(
  data_dir, "GCV_Full_Field_Project", "01B_Three_Slice_Reconciliation"
)

tol_yield <- 1e-4
tol_northing <- 1e-4

input_files <- c(full_file, reference_files)
exists_input <- file.exists(input_files)
print(data.frame(File = input_files, Exists = exists_input), row.names = FALSE)

if (!all(exists_input)) {
  stop("A source CSV is missing. Fix the filenames above; no analysis was performed.")
}

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
cat("\nOUTPUT DIRECTORY:\n", output_dir, "\n")


full <- read.csv(full_file, stringsAsFactors = FALSE, check.names = TRUE)
slices <- vector("list", length(reference_eastings))

required <- c("Yield", "Easting", "PassNo", "Pair",
              "Product", "Northing", "Pass")
num_fields <- c("Yield", "Easting", "PassNo", "Pair", "Northing", "Pass")

if (!all(required %in% names(full))) {
  stop("Full CSV lacks at least one required column: ",
       paste(setdiff(required, names(full)), collapse = ", "))
}

for (v in num_fields) {
  full[[v]] <- suppressWarnings(as.numeric(as.character(full[[v]])))
}
full$Product <- trimws(as.character(full$Product))

if (!all(is.finite(as.matrix(full[, num_fields])))) {
  stop("Full CSV contains non-finite entries in a required numeric field.")
}
if (!all(full$Product %in% c("B", "E"))) {
  stop("Full CSV has unexpected Product labels.")
}

for (s in seq_along(reference_files)) {
  z <- read.csv(reference_files[s], stringsAsFactors = FALSE,
                check.names = TRUE)
  if (!all(required %in% names(z))) {
    stop("Slice ", reference_eastings[s], " lacks: ",
         paste(setdiff(required, names(z)), collapse = ", "))
  }
  for (v in num_fields) {
    z[[v]] <- suppressWarnings(as.numeric(as.character(z[[v]])))
  }
  z$Product <- trimws(as.character(z$Product))
  if (!all(is.finite(as.matrix(z[, num_fields])))) {
    stop("Non-finite required numeric data in slice ", reference_eastings[s])
  }
  if (!all(z$Product %in% c("B", "E"))) {
    stop("Unexpected Product in slice ", reference_eastings[s])
  }
  slices[[s]] <- z
}

cat("Full CSV: ", nrow(full), " rows; ", ncol(full), " columns\n", sep = "")
for (s in seq_along(slices)) {
  cat("Slice ", reference_eastings[s], ": ", nrow(slices[[s]]),
      " rows\n", sep = "")
}


expected_eastings <- seq(2, 398, by = 2)
expected_passes <- 1:24

stopifnot(nrow(full) == 4776)
stopifnot(identical(sort(unique(full$Easting)), as.numeric(expected_eastings)))
stopifnot(identical(sort(unique(full$PassNo)), as.numeric(expected_passes)))

full_keys <- paste(full$Easting, full$PassNo, sep = "_")
stopifnot(!anyDuplicated(full_keys))

for (p in expected_passes) {
  z <- full[full$PassNo == p, , drop = FALSE]
  if (nrow(z) != length(expected_eastings) ||
      length(unique(z$Product)) != 1L ||
      length(unique(z$Northing)) != 1L ||
      length(unique(z$Pair)) != 1L ||
      length(unique(z$Pass)) != 1L) {
    stop("Common-design check failed for PassNo = ", p)
  }
}

for (s in seq_along(slices)) {
  z <- slices[[s]]
  if (nrow(z) != 24 || any(z$Easting != reference_eastings[s]) ||
      !identical(sort(z$PassNo), as.numeric(expected_passes)) ||
      anyDuplicated(z$PassNo)) {
    stop("Structure/key check failed for reference Easting ", reference_eastings[s])
  }
}
cat("COMMON DESIGN AND UNIQUE KEYS: PASS\n")


row_results <- data.frame()

for (s in seq_along(reference_eastings)) {
  e <- reference_eastings[s]
  from_full <- full[full$Easting == e, , drop = FALSE]
  from_slice <- slices[[s]]

  from_full <- from_full[order(from_full$PassNo), , drop = FALSE]
  location <- match(from_full$PassNo, from_slice$PassNo)
  if (anyNA(location)) stop("Could not match every PassNo at Easting ", e)
  from_slice <- from_slice[location, , drop = FALSE]

  comparison_e <- data.frame(
    Easting = rep(e, nrow(from_full)),
    PassNo = from_full$PassNo,
    Full_Yield = from_full$Yield,
    Slice_Yield = from_slice$Yield,
    Abs_Yield_Difference = abs(from_full$Yield - from_slice$Yield),
    Full_Northing = from_full$Northing,
    Slice_Northing = from_slice$Northing,
    Abs_Northing_Difference = abs(from_full$Northing - from_slice$Northing),
    Full_Product = from_full$Product,
    Slice_Product = from_slice$Product,
    Full_Pair = from_full$Pair,
    Slice_Pair = from_slice$Pair,
    Full_Pass = from_full$Pass,
    Slice_Pass = from_slice$Pass,
    stringsAsFactors = FALSE
  )

  comparison_e$Yield_Match <- comparison_e$Abs_Yield_Difference <= tol_yield
  comparison_e$Northing_Match <- comparison_e$Abs_Northing_Difference <= tol_northing
  comparison_e$Product_Match <- comparison_e$Full_Product == comparison_e$Slice_Product
  comparison_e$Pair_Match <- comparison_e$Full_Pair == comparison_e$Slice_Pair
  comparison_e$Pass_Match <- comparison_e$Full_Pass == comparison_e$Slice_Pass

  comparison_e$All_Match <- with(
    comparison_e,
    Yield_Match & Northing_Match & Product_Match & Pair_Match & Pass_Match
  )

  row_results <- rbind(row_results, comparison_e)
}

stopifnot(nrow(row_results) == 72)
print(head(row_results[, c("Easting", "PassNo", "Full_Yield",
                           "Slice_Yield", "Abs_Yield_Difference", "All_Match")], 9),
      row.names = FALSE, digits = 12)


summary_results <- data.frame(
  Easting = reference_eastings,
  Rows_Compared = integer(length(reference_eastings)),
  Max_Abs_Yield_Difference = numeric(length(reference_eastings)),
  Mean_Abs_Yield_Difference = numeric(length(reference_eastings)),
  Max_Abs_Northing_Difference = numeric(length(reference_eastings)),
  Failed_Rows = integer(length(reference_eastings)),
  Passed = logical(length(reference_eastings))
)

for (s in seq_along(reference_eastings)) {
  sub <- row_results[row_results$Easting == reference_eastings[s], , drop = FALSE]
  summary_results$Rows_Compared[s] <- nrow(sub)
  summary_results$Max_Abs_Yield_Difference[s] <- max(sub$Abs_Yield_Difference)
  summary_results$Mean_Abs_Yield_Difference[s] <- mean(sub$Abs_Yield_Difference)
  summary_results$Max_Abs_Northing_Difference[s] <- max(sub$Abs_Northing_Difference)
  summary_results$Failed_Rows[s] <- sum(!sub$All_Match)
  summary_results$Passed[s] <- (nrow(sub) == 24 && all(sub$All_Match))
}

failed_rows <- row_results[!row_results$All_Match, , drop = FALSE]

cat("\nRECONCILIATION SUMMARY:\n")
print(summary_results, row.names = FALSE, digits = 12)
cat("\nTOTAL FAILED ROWS:", nrow(failed_rows), "\n")
cat("ALL 72 RECORDS MATCH:", all(summary_results$Passed), "\n")


row_file <- file.path(output_dir, "Stage1B_Row_Level_Reconciliation.csv")
summary_file <- file.path(output_dir, "Stage1B_Summary.csv")
fail_file <- file.path(output_dir, "Stage1B_Failed_Rows.csv")
provenance_file <- file.path(output_dir, "Stage1B_Provenance.txt")

write.csv(row_results, row_file, row.names = FALSE)
write.csv(summary_results, summary_file, row.names = FALSE)
write.csv(failed_rows, fail_file, row.names = FALSE)

metadata <- file.info(input_files)
provenance_lines <- c(
  "Stage 1B source-file record",
  paste("R version:", R.version.string),
  paste("Yield tolerance:", tol_yield),
  paste("Northing tolerance:", tol_northing),
  "Only Yield, Northing, Product, Pair, Pass and keyed PassNo/Easting were compared.",
  "The slice Predicted column and extra index columns were intentionally excluded.",
  "Input file provenance:",
  paste(input_files, "| size bytes:", metadata$size,
        "| modified:", as.character(metadata$mtime))
)
writeLines(provenance_lines, provenance_file)

cat("\nSAVED FILES:\n")
cat(row_file, "\n", summary_file, "\n", fail_file, "\n",
    provenance_file, "\n", sep = "")

if (!all(summary_results$Passed)) {
  stop("STAGE 1B FAILED: review Stage1B_Failed_Rows.csv and the stated tolerances.")
}
cat("\n========================================\n")
cat("STAGE 1B RECONCILIATION: PASS\n")
cat("========================================\n")
